This project is for vendor portal. 
Where vendors can upload video and manage uploaded videos.