const filters = require('../filters'); 
const data = {
  "success": true,
  "filters": filters,
  "tableformatted": [
    [
      "Date",
      "Views",
      "Plays",
      "Avg Time",
      "Total Time (Hours)",
      "Ad-Calls",
      "Ad-Impression",
      "PreRoll Calls",
      "PreRoll Impression",
      "PostRoll Calls",
      "PostRoll Impression"
    ],
    [
      "2017-11-20",
      368113,
      227358,
      "1m 44s",
      6613,
      345360,
      148325,
      293019,
      135008,
      52341,
      13317
    ],
    [
      "2017-11-21",
      424002,
      267668,
      "1m 47s",
      8000,
      415983,
      181479,
      341601,
      162528,
      74382,
      18951
    ],
    [
      "2017-11-22",
      415165,
      269490,
      "1m 41s",
      7584,
      432406,
      176645,
      339993,
      157574,
      92413,
      19071
    ],
    [
      "2017-11-23",
      368785,
      237575,
      "1m 42s",
      6774,
      372147,
      163375,
      302020,
      146922,
      70127,
      16453
    ],
    [
      "2017-11-24",
      360927,
      227024,
      "1m 45s",
      6631,
      352941,
      148026,
      291368,
      133217,
      61573,
      14809
    ],
    [
      "2017-11-25",
      301224,
      197763,
      "1m 30s",
      4963,
      300185,
      123019,
      247352,
      111257,
      52833,
      11762
    ],
    [
      "2017-11-26",
      1,
      1,
      "10s",
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ]
  ]
};

const response = [
  {
    request: { method: 'POST' },
    response: (ctx) => {
      ctx.type = 'application/json';
      ctx.body = JSON.stringify(data);
    }
  }
]

module.exports = response;
