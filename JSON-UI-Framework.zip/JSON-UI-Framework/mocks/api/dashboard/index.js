const filters = require('../filters');
const data = {
  'success': true,
  "datetype": "customrange",
  "filters": filters,
  "dateranges": {
    "Yesterday": [
      "2017-11-25",
      "2017-11-25"
    ],
    "Last 7 days": [
      "2017-11-19",
      "2017-11-25"
    ],
    "Last 28 days": [
      "2017-10-29",
      "2017-11-25"
    ],
    "This Month": [
      "2017-11-01",
      "2017-11-25"
    ],
    "Last Month": [
      "2017-10-01",
      "2017-10-31"
    ],
    "Last 3 Months": [
      "2017-08-28",
      "2017-11-25"
    ]
  },
  "datefrom": "2017-11-19",
  "dateto": "2017-11-25",
  "days": 7,
  "dts": {
    "yesterday": {
      "title": "Yesterday",
      "sd": "2017-11-25",
      "days": 1,
      "st": "2017-11-25 00:00:00",
      "sts": 1511548200,
      "ed": "2017-11-25",
      "et": "2017-11-25 23:59:59",
      "ets": 1511634599
    },
    "last7days": {
      "title": "Last 7 days",
      "sd": "2017-11-19",
      "days": 7,
      "st": "2017-11-19 00:00:00",
      "sts": 1511029800,
      "ed": "2017-11-25",
      "et": "2017-11-25 23:59:59",
      "ets": 1511634599
    },
    "last28days": {
      "title": "Last 28 days",
      "sd": "2017-10-29",
      "days": 28,
      "st": "2017-10-29 00:00:00",
      "sts": 1509215400,
      "ed": "2017-11-25",
      "et": "2017-11-25 23:59:59",
      "ets": 1511634599
    },
    "thismonth": {
      "title": "This Month",
      "sd": "2017-11-01",
      "days": 25,
      "st": "2017-11-01 00:00:00",
      "sts": 1509474600,
      "ed": "2017-11-25",
      "et": "2017-11-25 23:59:59",
      "ets": 1511634599
    },
    "lastmonth": {
      "title": "Last Month",
      "sd": "2017-10-01",
      "days": "31",
      "st": "2017-10-01 00:00:00",
      "sts": 1506796200,
      "ed": "2017-10-31",
      "et": "2017-10-31 23:59:59",
      "ets": 1509474599
    },
    "last3months": {
      "title": "Last 3 Months",
      "sd": "2017-08-28",
      "days": 90,
      "st": "2017-08-28 00:00:00",
      "sts": 1503858600,
      "ed": "2017-11-25",
      "et": "2017-11-25 23:59:59",
      "ets": 1511634599
    },
    "customrange": {
      "title": "Custom Range",
      "sd": "2017-11-19",
      "ed": "2017-11-25",
      "days": 7,
      "st": "2017-11-19 00:00:00",
      "sts": 1511029800,
      "et": "2017-11-25 23:59:59",
      "ets": 1511634599
    }
  },
  "hideDateFilter": 0,
  "channel-filters": "et,toi,tf,np,tnr,etb2b,lng",
  "product-filters": "66,84,185,270,275,280,285,295,334,339,344,361",
  "app-filters": "",
  "islive": "",
  "search-filter": {
    "channel-filter": "et,toi,tf,np,tnr,etb2b,lng",
    "product-filter": "",
    "app-filter": "",
    "vendor-filter": "",
    "live-filter": ""
  },
  "vpbChartTI": "daily",
  "vv": 2580490,
  "vp": 1648389,
  "vprP": {
    "p": 64
  },
  "vpa": 463520,
  "vparP": {
    "p": 28
  },
  "ac": 2541961,
  "as": 1077455,
  "asrP": {
    "p": 42
  },
  "aspreroll": 971221,
  "aspostroll": 106234,
  "vvwab": 180563,
  "vvwabrP": {
    "p": 7
  },
  "vpii": 1166734,
  "vpiirP": {
    "p": 71
  },
  "vdsAdsTable": [
    [
      "Dates",
      "Video-Views",
      "Video-Plays",
      "Ad-Calls",
      "Ad-Impressions"
    ],
    [
      "19 Nov 2017",
      342274,
      221511,
      322939,
      136586
    ],
    [
      "20 Nov 2017",
      368113,
      227358,
      345360,
      148325
    ],
    [
      "21 Nov 2017",
      424002,
      267668,
      415983,
      181479
    ],
    [
      "22 Nov 2017",
      415165,
      269490,
      432406,
      176645
    ],
    [
      "23 Nov 2017",
      368785,
      237575,
      372147,
      163375
    ],
    [
      "24 Nov 2017",
      360927,
      227024,
      352941,
      148026
    ],
    [
      "25 Nov 2017",
      301224,
      197763,
      300185,
      123019
    ]
  ],
  "sdkavgLT": "1.72 s",
  "vavgPB": "0.42 s",
  "vavgLT": "1.62 s",
  "countrywiseMapData": [
    [
      "Country",
      "Plays"
    ],
    [
      "India",
      1166734
    ],
    [
      "United States",
      123424
    ],
    [
      "United arab emirates",
      55957
    ],
    [
      "Canada",
      32353
    ],
    [
      "Pakistan",
      30597
    ],
    [
      "United Kingdom",
      29521
    ],
    [
      "Saudi arabia",
      29168
    ],
    [
      "Australia",
      20187
    ],
    [
      "Singapore",
      17702
    ]
  ],
  "countrywiseViewCount": null,
  "countrywiseViewCountForPieChart": "null",
  "videoWiseViewCount": [
    [
      "Videos",
      "PlayBack"
    ],
    [
      "times-now-mini",
      117265
    ],
    [
      "Check out Neha Pendse's 'Pole' dance",
      72140
    ],
    [
      "04 Abhisek sacks his PR team",
      41910
    ],
    [
      "On cam: Karnataka minister slaps student for taking selfie",
      27043
    ],
    [
      "'Padmavati' row: Dead body found hanging at Nahargarh Fort; chilling note found alongside body",
      23260
    ],
    [
      "times-now",
      22950
    ],
    [
      "NEW Missle test fired from Sukhoi  30",
      21010
    ],
    [
      "Kapil Sharma opens up about all controversies surrounding him",
      16390
    ],
    [
      "Accident victim dies as onlookers click pictures",
      15431
    ],
    [
      "BrahMos reporter video",
      15170
    ]
  ],
  "sectionWiseViewCount": [
    [
      "Section",
      "Plays"
    ],
    [
      "videos",
      397379
    ],
    [
      "video-show",
      322846
    ],
    [
      "homepage",
      194660
    ],
    [
      "livetv-mini",
      116771
    ],
    [
      "AS-pages",
      107251
    ],
    [
      "home",
      87773
    ],
    [
      "Entertainment",
      58413
    ],
    [
      "TV",
      46847
    ],
    [
      "entertainment",
      43341
    ],
    [
      "City",
      41848
    ]
  ],
  "browserWiseViewCount": [
    [
      "Browser",
      "Plays"
    ],
    [
      "Chrome",
      1124942
    ],
    [
      "Safari",
      130462
    ],
    [
      "Firefox",
      115728
    ],
    [
      "Android Browser",
      93837
    ],
    [
      "WebView",
      64539
    ],
    [
      "IE",
      62736
    ],
    [
      "Opera",
      10518
    ],
    [
      "Facebook",
      8009
    ],
    [
      "MIUI Browser",
      5589
    ],
    [
      "UCBrowser",
      1235
    ]
  ]
};

const response = [
  {
    request: { method: 'POST' },
    response: (ctx) => {
      ctx.type = 'application/json';
      ctx.body = JSON.stringify(data);
    }
  }
]

module.exports = response;
