module.exports = {
  "children": [
    "filter"
  ],
  'filter': {
    "label": "Filters",
    "type": "Aside",
    "children": ["liveVod", "apps", "vendors"]
  },
  "vendors": {
    "label": "Vendor",
    "search": true,
    "type": "AccordionList",
    "childType": "Checkbox",
    "paramKey": "vendor",
    "children": ['timesNow', 'ians', 'gist', 'bangbiz']
  },
  "timesNow": {
    "label": "Times Now",
    "value": 45
  },
  "ians": {
    "label": "IANS",
    "value": 45
  },
  "gist": {
    "label": "GISt",
    "value": 45
  },
  "bangbiz": {
    "label": "Bangbiz",
    "value": 45
  },
  "apps": {
    "label": "Apps",
    "search": true,
    "type": "AccordionList",
    "childType": "Accordion",
    "paramKey": "channel",
    "children": [
      "33863",
      "zoom",
      "tn",
      "et",
      "sf",
      "303832",
      "303842",
      "303852",
      "bt",
      "cz",
      "tra",
      "303892",
      "303902",
      "toi",
      "303952",
      "fp",
      "sports",
      "tf",
      "bi",
      "st",
      "follo",
      "it",
      "tgp",
      "np",
      "til",
      "alive",
      "tnr",
      "303872",
      "test",
      "etb2b",
      "tj",
      "wwm",
      "gm",
      "tvid",
      "bccl",
      "tgbsl",
      "wi",
      "cb",
      "vb"
    ]
  },
  "33863": {
    "label": "Sameer P",
    "value": 33863
  },
  "zoom": {
    "label": "zoom",
    "value": "zoom"
  },
  "tn": {
    "label": "timesnow",
    "value": "tn"
  },
  "et": {
    "label": "For ETNow edited and all ET related.",
    "value": "et"
  },
  "sf": {
    "label": "Times India5 (short Formats)",
    "value": "sf"
  },
  "303832": {
    "label": "Times India6: serials, uttran",
    "value": 303832
  },
  "303842": {
    "label": "Times India7",
    "value": 303842
  },
  "303852": {
    "label": "Times India8",
    "value": 303852
  },
  "bt": {
    "label": "BT and Kyra videos",
    "value": "bt",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "190",
      "195"
    ]
  },
  "190": {
    "label": "Miss Kyra",
    "value": 190
  },
  "195": {
    "label": "Bombay Times",
    "value": 195
  },
  "cz": {
    "label": "For Citizen Reporter videos.",
    "value": "cz"
  },
  "tra": {
    "label": "Times radio audios",
    "value": "tra"
  },
  "303892": {
    "label": "Times India 12",
    "value": 303892
  },
  "303902": {
    "label": "Times India13",
    "value": 303902
  },
  "toi": {
    "label": "TOI",
    "value": "toi",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "18",
      "24",
      "42",
      "48",
      "54",
      "60",
      "66",
      "72",
      "78",
      "84",
      "205",
      "210",
      "215",
      "220",
      "255",
      "270",
      "275",
      "280",
      "285",
      "295",
      "300"
    ]
  },
  "18": {
    "label": "Denmark CMS",
    "value": 18
  },
  "24": {
    "label": "Economictimes",
    "value": 24
  },
  "42": {
    "label": "Maharashtra Times",
    "value": 42
  },
  "48": {
    "label": "NavGujrat",
    "value": 48
  },
  "54": {
    "label": "Navbharat Times",
    "value": 54
  },
  "60": {
    "label": "Samayam - Tamil",
    "value": 60
  },
  "66": {
    "label": "TimesOfIndia",
    "value": 66
  },
  "72": {
    "label": "Microsoft",
    "value": 72
  },
  "78": {
    "label": "Vijay Karnataka",
    "value": 78
  },
  "84": {
    "label": "TOI",
    "value": 84
  },
  "205": {
    "label": "eisamay",
    "value": 205
  },
  "210": {
    "label": "Samayam - Telugu",
    "value": 210
  },
  "215": {
    "label": "Samayam - Malayalam",
    "value": 215
  },
  "220": {
    "label": "Techradar",
    "value": 220
  },
  "255": {
    "label": "MSN",
    "value": 255
  },
  "270": {
    "label": "Mirrors",
    "value": 270
  },
  "275": {
    "label": "Entertainment",
    "value": 275
  },
  "280": {
    "label": "Lifestyle",
    "value": 280
  },
  "285": {
    "label": "TV",
    "value": 285
  },
  "295": {
    "label": "Beauty Pageants",
    "value": 295
  },
  "300": {
    "label": "IamGujarat",
    "value": 300
  },
  "303952": {
    "label": "Times India18",
    "value": 303952
  },
  "fp": {
    "label": "Filmi Pop (Times India19)",
    "value": "fp",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "200"
    ]
  },
  "200": {
    "label": "Filmipop",
    "value": 200
  },
  "sports": {
    "label": "Sports",
    "value": "sports"
  },
  "tf": {
    "label": "Times Food",
    "value": "tf",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "185"
    ]
  },
  "185": {
    "label": "Times Food",
    "value": 185
  },
  "bi": {
    "label": "Business Insider",
    "value": "bi",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "180"
    ]
  },
  "180": {
    "label": "Business Insider",
    "value": 180
  },
  "st": {
    "label": "Speaking Tree",
    "value": "st"
  },
  "follo": {
    "label": "Follo",
    "value": "follo",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "30",
      "250"
    ]
  },
  "30": {
    "label": "Follo",
    "value": 30
  },
  "250": {
    "label": "Follo",
    "value": 250
  },
  "it": {
    "label": "Indiatimes lifestyle Network",
    "value": "it",
    "paramKey": "products",
    "children": [
      "36",
      "240",
      "245"
    ]
  },
  "36": {
    "type": "Accordion",
    "label": "Indiatimes",
    "value": 36,
    "childType": "Checkbox",
    "paramKey": "apps",
    "selected": true,
    "children": [
      "Testingtoikslsi131500490"
    ]
  },
  "Testingtoikslsi131500490": {
    "label": "testing_toi",
    "value": "Testingtoikslsi131500490"
  },
  "240": {
    "type": "Checkbox",
    "label": "MensXp",
    "value": 240
  },
  "245": {
    "type": "Checkbox",
    "label": "iDiva",
    "value": 245
  },
  "tgp": {
    "label": "Times Global Partner",
    "value": "tgp",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "175"
    ]
  },
  "175": {
    "label": "Times Global Partner",
    "value": 175
  },
  "np": {
    "label": "News Point",
    "value": "np",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "160",
      "260"
    ]
  },
  "160": {
    "label": "Newspoint",
    "value": 160
  },
  "260": {
    "label": "News Point",
    "value": 260
  },
  "til": {
    "label": "TIL (Internal)",
    "value": "til",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "170"
    ]
  },
  "170": {
    "label": "Corporate Design",
    "value": 170
  },
  "alive": {
    "label": "Alive",
    "value": "alive",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "155",
      "265"
    ]
  },
  "155": {
    "label": "Times Mobile - Alive",
    "value": 155
  },
  "265": {
    "label": "Alive",
    "value": 265
  },
  "tnr": {
    "label": "Times India 3 (Times Now Radio)",
    "value": "tnr"
  },
  "303872": {
    "label": "Times India10",
    "value": 303872
  },
  "test": {
    "label": "test",
    "value": "test",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "165"
    ]
  },
  "165": {
    "label": "test",
    "value": 165
  },
  "etb2b": {
    "label": "ET B2B",
    "value": "etb2b",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "100",
      "105",
      "110",
      "115",
      "120",
      "125",
      "130",
      "135",
      "140",
      "145",
      "150"
    ]
  },
  "100": {
    "label": "ETTech",
    "value": 100
  },
  "105": {
    "label": "ETAuto",
    "value": 105
  },
  "110": {
    "label": "ETReal Estate",
    "value": 110
  },
  "115": {
    "label": "ETRetail",
    "value": 115
  },
  "120": {
    "label": "ETBrandEquity",
    "value": 120
  },
  "125": {
    "label": "ETTelecom",
    "value": 125
  },
  "130": {
    "label": "ETHealth",
    "value": 130
  },
  "135": {
    "label": "ETCIO",
    "value": 135
  },
  "140": {
    "label": "ETEnergy",
    "value": 140
  },
  "145": {
    "label": "ETCFO",
    "value": 145
  },
  "150": {
    "label": "ETCISO",
    "value": 150
  },
  "tj": {
    "label": "timesjobs",
    "value": "tj",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "95"
    ]
  },
  "95": {
    "label": "Times Jobs",
    "value": 95
  },
  "wwm": {
    "label": "World Wide Media",
    "value": "wwm",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "225",
      "230"
    ]
  },
  "225": {
    "label": "Femina",
    "value": 225
  },
  "230": {
    "label": "Filmfare",
    "value": 230
  },
  "gm": {
    "label": "Growth Marketing",
    "value": "gm",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "290"
    ]
  },
  "290": {
    "label": "Gaana Marketing",
    "value": 290
  },
  "tvid": {
    "label": "Times Internet (Public)",
    "value": "tvid"
  },
  "bccl": {
    "label": "BCCL",
    "value": "bccl"
  },
  "tgbsl": {
    "label": "Times Television Network",
    "value": "tgbsl"
  },
  "wi": {
    "label": "Willo",
    "value": "wi"
  },
  "cb": {
    "label": "Cricbuzz",
    "value": "cb"
  },
  "vb": {
    "label": "Videobrew",
    "value": "vb",
    "childType": "Checkbox",
    "paramKey": "products",
    "children": [
      "5"
    ]
  },
  "5": {
    "label": "MSN",
    "value": 5
  },
  'liveVod': {
    "type":  "SwitchContainer",
    'paramKey': 'isLive',
    'childType': 'Switch',
    'children': ['live', 'vod', 'allLiveVod']
  },
  'live': {
    'label': 'Live',
    'value': '1',
    'selected': true
  },
  'vod': {
    'label': 'Vod',
    'value': '2'
  },
  'allLiveVod': {
    'label': 'All',
    'value': '0'
  },
  'dateFilter': {
    'value': '2017-11-22|2017-11-28',
    'type': 'DateRangeFilter'
  }
}
