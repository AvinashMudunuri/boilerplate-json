const user = require('./user');
const realTime = require('./realTime');
const dailyReport = require('./dailyReport');
const dashboard = require('./dashboard');
const vendorReport = require('./vendorReport');
const sydicationReport = require('./sydicationReport');

const api = [
  {
    route: '/user/:action',
    responses: user
  },
  {
    route: '/realtime',
    responses: realTime
  },
  {
    route: '/dailyreport',
    responses: dailyReport
  },
  {
    route: '/dashboard',
    responses: dashboard
  },
  {
    route: '/vendorreport',
    responses: vendorReport
  },
  {
    route: '/sydicationreport',
    responses: sydicationReport
  }
];

module.exports = api;
