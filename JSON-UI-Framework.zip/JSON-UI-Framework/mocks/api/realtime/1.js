const filters = require('../filters'); 
module.exports = {
  "success": true,
  "filters": filters,
  "country": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 55,
    "buckets": [
      {
        "key": "India",
        "doc_count": 827
      },
      {
        "key": "United States",
        "doc_count": 72
      },
      {
        "key": "United arab emirates",
        "doc_count": 43
      },
      {
        "key": "Saudi arabia",
        "doc_count": 30
      },
      {
        "key": "Singapore",
        "doc_count": 15
      },
      {
        "key": "Pakistan",
        "doc_count": 14
      },
      {
        "key": "Australia",
        "doc_count": 11
      },
      {
        "key": "Canada",
        "doc_count": 10
      },
      {
        "key": "Kuwait",
        "doc_count": 6
      },
      {
        "key": "others",
        "doc_count": 55
      }
    ]
  },
  "product": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "TOI",
        "doc_count": 1081
      },
      {
        "key": "Happytrips",
        "doc_count": 3
      },
      {
        "key": "others",
        "doc_count": 0
      }
    ]
  },
  "loadtime": {
    "count": 1084,
    "min": 0,
    "max": 30000,
    "avg": 3.75,
    "sum": 4068057
  },
  "timespent": {
    "count": 1084,
    "min": 431,
    "max": 41245379,
    "avg": 441624.8754612546,
    "sum": 478721365
  },
  "stype": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": 0,
        "key_as_string": "false",
        "doc_count": 1028
      },
      {
        "key": 1,
        "key_as_string": "true",
        "doc_count": 56
      }
    ]
  },
  "addisabled": {
    "value": 16
  },
  "videos": {
    "value": 252
  },
  "adblocker": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": 0,
        "key_as_string": "false",
        "doc_count": 1000
      },
      {
        "key": 1,
        "key_as_string": "true",
        "doc_count": 84
      }
    ]
  },
  "users": {
    "value": "924"
  },
  "sections": {
    "doc_count_error_upper_bound": 5,
    "sum_other_doc_count": 265,
    "buckets": [
      {
        "key": "video-show",
        "doc_count": 278
      },
      {
        "key": "videos",
        "doc_count": 199
      },
      {
        "key": "AS-pages",
        "doc_count": 147
      },
      {
        "key": "homepage",
        "doc_count": 110
      },
      {
        "key": "india",
        "doc_count": 81
      },
      {
        "key": "others",
        "doc_count": 265
      }
    ]
  },
  "platform": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "Web",
        "doc_count": 588
      },
      {
        "key": "mWeb",
        "doc_count": 496
      },
      {
        "key": "others",
        "doc_count": 0
      }
    ]
  },
  "channels": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "TOI",
        "doc_count": 1084
      },
      {
        "key": "others",
        "doc_count": 0
      }
    ]
  },
  "trendingv": {
    "doc_count_error_upper_bound": 10,
    "sum_other_doc_count": 647,
    "buckets": [
      {
        "key": "1x14hhrgg9",
        "doc_count": 179
      },
      {
        "key": "1x14hhsgg9",
        "doc_count": 64
      },
      {
        "key": "1x14fm7gg9",
        "doc_count": 43
      },
      {
        "key": "times-now",
        "doc_count": 38
      },
      {
        "key": "1x1emmpggl",
        "doc_count": 30
      },
      {
        "key": "1x14hr4gg9",
        "doc_count": 29
      },
      {
        "key": "1x14fedgg9",
        "doc_count": 27
      },
      {
        "key": "1x14h8pgg9",
        "doc_count": 27
      }
    ]
  },
  "stats": {
    "buckets": {
      "adblocked": "84",
      "adcanplay": "1,000",
      "aderrors": "429",
      "adplayed": "462",
      "livestream": "56",
      "vodstream": "1,028",
      "adblockedper": "8",
      "fillrate": "46",
      "aderrorper": "43"
    }
  },
  "browser": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 76,
    "buckets": [
      {
        "key": "Chrome",
        "doc_count": 675
      },
      {
        "key": "Safari",
        "doc_count": 108
      },
      {
        "key": "Firefox",
        "doc_count": 86
      },
      {
        "key": "IE",
        "doc_count": 65
      },
      {
        "key": "Android Browser",
        "doc_count": 51
      },
      {
        "key": "others",
        "doc_count": 76
      }
    ]
  },
  "timeplay": {
    "count": 1026,
    "min": 0,
    "max": 3584,
    "avg": 80,
    "sum": 22.938055555555554
  },
  "live": {
    "doc_count": 56,
    "data": {
      "doc_count_error_upper_bound": 0,
      "sum_other_doc_count": 0,
      "buckets": [
        {
          "key": "times-now",
          "doc_count": 38
        },
        {
          "key": "times-now-mini",
          "doc_count": 12
        },
        {
          "key": "et-now",
          "doc_count": 2
        },
        {
          "key": "mirrornow",
          "doc_count": 2
        },
        {
          "key": "times-now-audio",
          "doc_count": 2
        }
      ]
    },
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "times-now",
        "doc_count": 38
      },
      {
        "key": "times-now-mini",
        "doc_count": 12
      },
      {
        "key": "et-now",
        "doc_count": 2
      },
      {
        "key": "mirrornow",
        "doc_count": 2
      },
      {
        "key": "times-now-audio",
        "doc_count": 2
      }
    ]
  },
  "total": 1084,
  "trendingvid": [
    {
      "key": "Ivanka Trump in Hyderabad to attend GES 2017",
      "doc_count": 179
    },
    {
      "key": "Only in U.P.: Herd of donkeys jailed for 4 days! Granted bail!",
      "doc_count": 64
    },
    {
      "key": "Miss World 2017 Manushi Chhillar Gets Candid",
      "doc_count": 43
    },
    {
      "key": "times-now",
      "doc_count": 38
    },
    {
      "key": "Check out Neha Pendse's 'Pole' dance",
      "doc_count": 30
    },
    {
      "key": "DOG CARRYING FETUS28",
      "doc_count": 29
    },
    {
      "key": "Lalu s son Tej Pratap threatens to peel off PM Modi s skin",
      "doc_count": 27
    },
    {
      "key": "MN Mob vandalises Kalyan Hospital",
      "doc_count": 27
    },
    {
      "key": "others",
      "doc_count": 647
    }
  ],
  "usersbymin": [
    {
      "key_as_string": "2017-11-28 11:26:46",
      "key": "11:26:46",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 11:26:47",
      "key": "11:26:47",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 11:26:48",
      "key": "11:26:48",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 11:26:49",
      "key": "11:26:49",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 11:26:50",
      "key": "11:26:50",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 11:26:51",
      "key": "11:26:51",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 11:26:52",
      "key": "11:26:52",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 11:26:53",
      "key": "11:26:53",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 11:26:54",
      "key": "11:26:54",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 11:26:55",
      "key": "11:26:55",
      "doc_count": 9
    },
    {
      "key_as_string": "2017-11-28 11:26:56",
      "key": "11:26:56",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 11:26:57",
      "key": "11:26:57",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 11:26:58",
      "key": "11:26:58",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 11:26:59",
      "key": "11:26:59",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 11:27:00",
      "key": "11:27:00",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 11:27:01",
      "key": "11:27:01",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 11:27:02",
      "key": "11:27:02",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 11:27:03",
      "key": "11:27:03",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 11:27:04",
      "key": "11:27:04",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 11:27:05",
      "key": "11:27:05",
      "doc_count": 5
    },
    {
      "key_as_string": "2017-11-28 11:27:06",
      "key": "11:27:06",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 11:27:07",
      "key": "11:27:07",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 11:27:08",
      "key": "11:27:08",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 11:27:09",
      "key": "11:27:09",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 11:27:10",
      "key": "11:27:10",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 11:27:11",
      "key": "11:27:11",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 11:27:12",
      "key": "11:27:12",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 11:27:13",
      "key": "11:27:13",
      "doc_count": 5
    },
    {
      "key_as_string": "2017-11-28 11:27:14",
      "key": "11:27:14",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 11:27:15",
      "key": "11:27:15",
      "doc_count": 1
    }
  ]
}
