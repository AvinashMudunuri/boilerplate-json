const filters = require('../filters');
module.exports = {
  "success": true,
  "filters": filters,
  "country": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 69,
    "buckets": [
      {
        "key": "India",
        "doc_count": 761
      },
      {
        "key": "United States",
        "doc_count": 43
      },
      {
        "key": "Saudi arabia",
        "doc_count": 37
      },
      {
        "key": "United arab emirates",
        "doc_count": 32
      },
      {
        "key": "Singapore",
        "doc_count": 15
      },
      {
        "key": "Pakistan",
        "doc_count": 14
      },
      {
        "key": "Qatar",
        "doc_count": 14
      },
      {
        "key": "Canada",
        "doc_count": 11
      },
      {
        "key": "United Kingdom",
        "doc_count": 8
      },
      {
        "key": "others",
        "doc_count": 69
      }
    ]
  },
  "product": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "TOI",
        "doc_count": 993
      },
      {
        "key": "Happytrips",
        "doc_count": 13
      },
      {
        "key": "others",
        "doc_count": 0
      }
    ]
  },
  "loadtime": {
    "count": 1006,
    "min": 0,
    "max": 30000,
    "avg": 3.54,
    "sum": 3565138
  },
  "timespent": {
    "count": 1006,
    "min": 2,
    "max": 43922965,
    "avg": 344220.689860835,
    "sum": 346286014
  },
  "stype": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": 0,
        "key_as_string": "false",
        "doc_count": 962
      },
      {
        "key": 1,
        "key_as_string": "true",
        "doc_count": 44
      }
    ]
  },
  "addisabled": {
    "value": 12
  },
  "videos": {
    "value": 276
  },
  "adblocker": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": 0,
        "key_as_string": "false",
        "doc_count": 931
      },
      {
        "key": 1,
        "key_as_string": "true",
        "doc_count": 75
      }
    ]
  },
  "users": {
    "value": "841"
  },
  "sections": {
    "doc_count_error_upper_bound": 5,
    "sum_other_doc_count": 199,
    "buckets": [
      {
        "key": "video-show",
        "doc_count": 309
      },
      {
        "key": "videos",
        "doc_count": 208
      },
      {
        "key": "AS-pages",
        "doc_count": 139
      },
      {
        "key": "homepage",
        "doc_count": 110
      },
      {
        "key": "india",
        "doc_count": 38
      },
      {
        "key": "others",
        "doc_count": 199
      }
    ]
  },
  "platform": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "Web",
        "doc_count": 600
      },
      {
        "key": "mWeb",
        "doc_count": 406
      },
      {
        "key": "others",
        "doc_count": 0
      }
    ]
  },
  "channels": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "TOI",
        "doc_count": 1006
      },
      {
        "key": "others",
        "doc_count": 0
      }
    ]
  },
  "trendingv": {
    "doc_count_error_upper_bound": 11,
    "sum_other_doc_count": 700,
    "buckets": [
      {
        "key": "1x14hhrgg9",
        "doc_count": 110
      },
      {
        "key": "1x14hhsgg9",
        "doc_count": 47
      },
      {
        "key": "times-now",
        "doc_count": 31
      },
      {
        "key": "1x14fm7gg9",
        "doc_count": 28
      },
      {
        "key": "1x1emmpggl",
        "doc_count": 26
      },
      {
        "key": "1x14hrngg9",
        "doc_count": 22
      },
      {
        "key": "1x14h8pgg9",
        "doc_count": 21
      },
      {
        "key": "1x14hq7gg9",
        "doc_count": 21
      }
    ]
  },
  "stats": {
    "buckets": {
      "adblocked": "75",
      "adcanplay": "931",
      "aderrors": "436",
      "adplayed": "397",
      "livestream": "44",
      "vodstream": "962",
      "adblockedper": "8",
      "fillrate": "43",
      "aderrorper": "47"
    }
  },
  "browser": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 65,
    "buckets": [
      {
        "key": "Chrome",
        "doc_count": 686
      },
      {
        "key": "Firefox",
        "doc_count": 75
      },
      {
        "key": "Safari",
        "doc_count": 70
      },
      {
        "key": "Android Browser",
        "doc_count": 54
      },
      {
        "key": "IE",
        "doc_count": 36
      },
      {
        "key": "others",
        "doc_count": 65
      }
    ]
  },
  "timeplay": {
    "count": 961,
    "min": 0,
    "max": 2851,
    "avg": 74,
    "sum": 19.72388888888889
  },
  "live": {
    "doc_count": 44,
    "data": {
      "doc_count_error_upper_bound": 0,
      "sum_other_doc_count": 0,
      "buckets": [
        {
          "key": "times-now",
          "doc_count": 31
        },
        {
          "key": "times-now-mini",
          "doc_count": 6
        },
        {
          "key": "zoom-tv",
          "doc_count": 4
        },
        {
          "key": "et-now",
          "doc_count": 2
        },
        {
          "key": "mirrornow",
          "doc_count": 1
        }
      ]
    },
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "times-now",
        "doc_count": 31
      },
      {
        "key": "times-now-mini",
        "doc_count": 6
      },
      {
        "key": "zoom-tv",
        "doc_count": 4
      },
      {
        "key": "et-now",
        "doc_count": 2
      },
      {
        "key": "mirrornow",
        "doc_count": 1
      }
    ]
  },
  "total": 1006,
  "trendingvid": [
    {
      "key": "Ivanka Trump in Hyderabad to attend GES 2017",
      "doc_count": 110
    },
    {
      "key": "Only in U.P.: Herd of donkeys jailed for 4 days! Granted bail!",
      "doc_count": 47
    },
    {
      "key": "times-now",
      "doc_count": 31
    },
    {
      "key": "Miss World 2017 Manushi Chhillar Gets Candid",
      "doc_count": 28
    },
    {
      "key": "Check out Neha Pendse's 'Pole' dance",
      "doc_count": 26
    },
    {
      "key": "Hafiz Saeed wants his name off UN terror list1",
      "doc_count": 22
    },
    {
      "key": "MN Mob vandalises Kalyan Hospital",
      "doc_count": 21
    },
    {
      "key": "Salman Khan gets Bipasha and Karan\u2019s ad removed from his TV show?",
      "doc_count": 21
    },
    {
      "key": "others",
      "doc_count": 700
    }
  ],
  "usersbymin": [
    {
      "key_as_string": "2017-11-28 12:10:43",
      "key": "12:10:43",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:10:44",
      "key": "12:10:44",
      "doc_count": 5
    },
    {
      "key_as_string": "2017-11-28 12:10:45",
      "key": "12:10:45",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 12:10:46",
      "key": "12:10:46",
      "doc_count": 6
    },
    {
      "key_as_string": "2017-11-28 12:10:47",
      "key": "12:10:47",
      "doc_count": 5
    },
    {
      "key_as_string": "2017-11-28 12:10:48",
      "key": "12:10:48",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:10:49",
      "key": "12:10:49",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:10:50",
      "key": "12:10:50",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:10:51",
      "key": "12:10:51",
      "doc_count": 6
    },
    {
      "key_as_string": "2017-11-28 12:10:52",
      "key": "12:10:52",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:10:53",
      "key": "12:10:53",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:10:54",
      "key": "12:10:54",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:10:55",
      "key": "12:10:55",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:10:56",
      "key": "12:10:56",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:10:57",
      "key": "12:10:57",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 12:10:58",
      "key": "12:10:58",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:10:59",
      "key": "12:10:59",
      "doc_count": 5
    },
    {
      "key_as_string": "2017-11-28 12:11:00",
      "key": "12:11:00",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 12:11:01",
      "key": "12:11:01",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:11:02",
      "key": "12:11:02",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:11:03",
      "key": "12:11:03",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:11:04",
      "key": "12:11:04",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 12:11:05",
      "key": "12:11:05",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:11:06",
      "key": "12:11:06",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:11:07",
      "key": "12:11:07",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:11:08",
      "key": "12:11:08",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:11:09",
      "key": "12:11:09",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:11:10",
      "key": "12:11:10",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:11:11",
      "key": "12:11:11",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:11:12",
      "key": "12:11:12",
      "doc_count": 3
    }
  ]
}
