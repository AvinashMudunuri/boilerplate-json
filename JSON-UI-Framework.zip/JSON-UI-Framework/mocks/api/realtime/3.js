const filters = require('../filters');
module.exports = {
  "success": true,
  "filters": filters,
  "country": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 67,
    "buckets": [
      {
        "key": "India",
        "doc_count": 771
      },
      {
        "key": "United States",
        "doc_count": 42
      },
      {
        "key": "Saudi arabia",
        "doc_count": 36
      },
      {
        "key": "United arab emirates",
        "doc_count": 30
      },
      {
        "key": "Singapore",
        "doc_count": 15
      },
      {
        "key": "Qatar",
        "doc_count": 14
      },
      {
        "key": "Pakistan",
        "doc_count": 13
      },
      {
        "key": "Canada",
        "doc_count": 11
      },
      {
        "key": "United Kingdom",
        "doc_count": 9
      },
      {
        "key": "others",
        "doc_count": 67
      }
    ]
  },
  "product": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "TOI",
        "doc_count": 998
      },
      {
        "key": "Happytrips",
        "doc_count": 12
      },
      {
        "key": "others",
        "doc_count": 0
      }
    ]
  },
  "loadtime": {
    "count": 1010,
    "min": 0,
    "max": 30000,
    "avg": 3.62,
    "sum": 3655834
  },
  "timespent": {
    "count": 1010,
    "min": 2,
    "max": 43739704,
    "avg": 253532.59504950495,
    "sum": 256067921
  },
  "stype": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": 0,
        "key_as_string": "false",
        "doc_count": 970
      },
      {
        "key": 1,
        "key_as_string": "true",
        "doc_count": 40
      }
    ]
  },
  "addisabled": {
    "value": 11
  },
  "videos": {
    "value": 279
  },
  "adblocker": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": 0,
        "key_as_string": "false",
        "doc_count": 937
      },
      {
        "key": 1,
        "key_as_string": "true",
        "doc_count": 73
      }
    ]
  },
  "users": {
    "value": "837"
  },
  "sections": {
    "doc_count_error_upper_bound": 5,
    "sum_other_doc_count": 196,
    "buckets": [
      {
        "key": "video-show",
        "doc_count": 315
      },
      {
        "key": "videos",
        "doc_count": 211
      },
      {
        "key": "AS-pages",
        "doc_count": 138
      },
      {
        "key": "homepage",
        "doc_count": 107
      },
      {
        "key": "india",
        "doc_count": 39
      },
      {
        "key": "others",
        "doc_count": 196
      }
    ]
  },
  "platform": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "Web",
        "doc_count": 597
      },
      {
        "key": "mWeb",
        "doc_count": 413
      },
      {
        "key": "others",
        "doc_count": 0
      }
    ]
  },
  "channels": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "TOI",
        "doc_count": 1010
      },
      {
        "key": "others",
        "doc_count": 0
      }
    ]
  },
  "trendingv": {
    "doc_count_error_upper_bound": 11,
    "sum_other_doc_count": 707,
    "buckets": [
      {
        "key": "1x14hhrgg9",
        "doc_count": 113
      },
      {
        "key": "1x14hhsgg9",
        "doc_count": 48
      },
      {
        "key": "1x14fm7gg9",
        "doc_count": 28
      },
      {
        "key": "1x1emmpggl",
        "doc_count": 27
      },
      {
        "key": "1x14hrcgg9",
        "doc_count": 23
      },
      {
        "key": "times-now",
        "doc_count": 23
      },
      {
        "key": "1x14hrngg9",
        "doc_count": 21
      },
      {
        "key": "1x14hq7gg9",
        "doc_count": 20
      }
    ]
  },
  "stats": {
    "buckets": {
      "adblocked": "73",
      "adcanplay": "937",
      "aderrors": "444",
      "adplayed": "395",
      "livestream": "40",
      "vodstream": "970",
      "adblockedper": "8",
      "fillrate": "42",
      "aderrorper": "47"
    }
  },
  "browser": {
    "doc_count_error_upper_bound": 0,
    "sum_other_doc_count": 64,
    "buckets": [
      {
        "key": "Chrome",
        "doc_count": 695
      },
      {
        "key": "Firefox",
        "doc_count": 70
      },
      {
        "key": "Safari",
        "doc_count": 70
      },
      {
        "key": "Android Browser",
        "doc_count": 53
      },
      {
        "key": "IE",
        "doc_count": 37
      },
      {
        "key": "others",
        "doc_count": 64
      }
    ]
  },
  "timeplay": {
    "count": 969,
    "min": 0,
    "max": 2851,
    "avg": 74,
    "sum": 19.87388888888889
  },
  "live": {
    "doc_count": 40,
    "data": {
      "doc_count_error_upper_bound": 0,
      "sum_other_doc_count": 0,
      "buckets": [
        {
          "key": "times-now",
          "doc_count": 25
        },
        {
          "key": "et-now",
          "doc_count": 5
        },
        {
          "key": "zoom-tv",
          "doc_count": 5
        },
        {
          "key": "times-now-mini",
          "doc_count": 4
        },
        {
          "key": "mirror-now",
          "doc_count": 1
        }
      ]
    },
    "sum_other_doc_count": 0,
    "buckets": [
      {
        "key": "times-now",
        "doc_count": 25
      },
      {
        "key": "et-now",
        "doc_count": 5
      },
      {
        "key": "zoom-tv",
        "doc_count": 5
      },
      {
        "key": "times-now-mini",
        "doc_count": 4
      },
      {
        "key": "mirror-now",
        "doc_count": 1
      }
    ]
  },
  "total": 1010,
  "trendingvid": [
    {
      "key": "Ivanka Trump in Hyderabad to attend GES 2017",
      "doc_count": 113
    },
    {
      "key": "Only in U.P.: Herd of donkeys jailed for 4 days! Granted bail!",
      "doc_count": 48
    },
    {
      "key": "Miss World 2017 Manushi Chhillar Gets Candid",
      "doc_count": 28
    },
    {
      "key": "Check out Neha Pendse's 'Pole' dance",
      "doc_count": 27
    },
    {
      "key": "Maid found hanging in Doctor s residence 28Nov",
      "doc_count": 23
    },
    {
      "key": "times-now",
      "doc_count": 23
    },
    {
      "key": "Hafiz Saeed wants his name off UN terror list1",
      "doc_count": 21
    },
    {
      "key": "Salman Khan gets Bipasha and Karan\u2019s ad removed from his TV show?",
      "doc_count": 20
    },
    {
      "key": "others",
      "doc_count": 707
    }
  ],
  "usersbymin": [
    {
      "key_as_string": "2017-11-28 12:10:51",
      "key": "12:10:51",
      "doc_count": 6
    },
    {
      "key_as_string": "2017-11-28 12:10:52",
      "key": "12:10:52",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:10:53",
      "key": "12:10:53",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:10:54",
      "key": "12:10:54",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:10:55",
      "key": "12:10:55",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:10:56",
      "key": "12:10:56",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:10:57",
      "key": "12:10:57",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 12:10:58",
      "key": "12:10:58",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:10:59",
      "key": "12:10:59",
      "doc_count": 5
    },
    {
      "key_as_string": "2017-11-28 12:11:00",
      "key": "12:11:00",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 12:11:01",
      "key": "12:11:01",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:11:02",
      "key": "12:11:02",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:11:03",
      "key": "12:11:03",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:11:04",
      "key": "12:11:04",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 12:11:05",
      "key": "12:11:05",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:11:06",
      "key": "12:11:06",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 12:11:07",
      "key": "12:11:07",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:11:08",
      "key": "12:11:08",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:11:09",
      "key": "12:11:09",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:11:10",
      "key": "12:11:10",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:11:11",
      "key": "12:11:11",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:11:12",
      "key": "12:11:12",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:11:13",
      "key": "12:11:13",
      "doc_count": 2
    },
    {
      "key_as_string": "2017-11-28 12:11:14",
      "key": "12:11:14",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:11:15",
      "key": "12:11:15",
      "doc_count": 3
    },
    {
      "key_as_string": "2017-11-28 12:11:16",
      "key": "12:11:16",
      "doc_count": 6
    },
    {
      "key_as_string": "2017-11-28 12:11:17",
      "key": "12:11:17",
      "doc_count": 1
    },
    {
      "key_as_string": "2017-11-28 12:11:18",
      "key": "12:11:18",
      "doc_count": 4
    },
    {
      "key_as_string": "2017-11-28 12:11:19",
      "key": "12:11:19",
      "doc_count": 0
    },
    {
      "key_as_string": "2017-11-28 12:11:20",
      "key": "12:11:20",
      "doc_count": 1
    }
  ]
}
