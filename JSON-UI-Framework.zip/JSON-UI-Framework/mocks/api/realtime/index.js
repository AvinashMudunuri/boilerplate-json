let index = [1,2,3];
const response = [
  {
    request: { method: 'POST' },
    response: (ctx) => {   
      ctx.type = 'application/json';
      ctx.body = JSON.stringify(require(`./${index[Math.floor(Math.random()*index.length)]}`));
    }
  }
]

module.exports = response;
