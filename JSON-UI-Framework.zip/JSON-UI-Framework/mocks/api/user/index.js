const response = [
  {
    request: { method: 'POST' },
    response: (ctx, action) => {
      ctx.type = 'application/json';
      ctx.body = JSON.stringify(require(`./${action}`));
    }
  }
]

module.exports = response;
