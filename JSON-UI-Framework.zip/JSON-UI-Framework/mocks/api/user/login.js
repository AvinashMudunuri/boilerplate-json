module.exports = {
  success: true,
  uid: 1234
};
