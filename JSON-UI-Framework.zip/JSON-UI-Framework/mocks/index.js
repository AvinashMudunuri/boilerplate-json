const api = require('./api');
const ui = require('./ui');

module.exports = MockBase => class MyMockModule extends MockBase {
  mocks(options) {
    return [
      ...api,
      ...ui
    ]
  }
}
