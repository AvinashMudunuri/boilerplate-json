module.exports = {
  'name': 'filterBreadcrumbCont',
  'type': 'FieldsRow',
  'className': 'mt-3 clearfix js-filterBreadcrumb',
  'matchCondition': {
    'filterSelected': true,
    'filterApplied': true
  },
  'fields': [
    {
      'name': 'filterBreadcrumbs',
      'type': 'FilterBreadcrumbs',
      'className': 'col-12 col-sm-10 p-xs-0'
    },
    {
      'name': 'filterClearBtn',
      'type': 'ButtonField',
      'containerClass': 'col-3 col-sm-1 m-0 p-0 mt-xs-3 mt-sm-0',
      'className': 'btn-sm w-100 bg-light',
      'label': 'Clear',
      'action': {
        'type': 'clearFilterSelection'
      },
      'matchCondition': {
        'filterSelected': true,
        'filterApplied': true
      }
    },
    {
      'name': 'filterApplyBtn',
      'type': 'ButtonField',
      'containerClass': 'col-3 col-sm-1 m-0 p-0 pl-1 mt-xs-3 mt-sm-0',
      'className': 'btn-sm w-100 bg-primary',
      'label': 'Apply',
      'action': {
        'type': 'applyFilterSelection'
      },
      'matchCondition': {
        'filterSelected': true
      }
    }
  ]
};
