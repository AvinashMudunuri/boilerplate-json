module.exports = {
  'name': 'pageHeader',
  'type': 'PageHeader',
  'homeLink': '/dashboard',
  'navLinks': [
    {
      'href': '/realtime',
      'label': 'Real-Time'
    },
    {
      'href': '/dailyreport',
      'label': 'Daily Reports'
    },
    {
      'href': '/vendorreport',
      'label': 'Vendor Reports'
    },
    {
      'href': '/sydicationreport',
      'label': 'Sydication Reports'
    }
  ]
};
