module.exports = {
  'name': 'sidebar',
  'type': 'Sidebar',
  'navLinks': [
    {
      'href': '/dashboard',
      'label': 'Dashboard'
    },
    {
      'href': '/realtime',
      'label': 'Real-Time'
    },
    {
      'href': '/dailyreport',
      'label': 'Daily Reports'
    },
    {
      'href': '/vendorreport',
      'label': 'Vendor Reports'
    },
    {
      'href': '/sydicationreport',
      'label': 'Sydication Reports'
    }    
  ]
};
