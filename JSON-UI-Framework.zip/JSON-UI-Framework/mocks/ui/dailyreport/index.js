const pageHeaders = require('../common/pageHeader');
const sidebar = require('../common/sidebar');
const breadcrumb = require('../common/breadcrumb');
const filters = require('../../api/filters');
module.exports = {
  'name': 'dailyreport',
  'api': {
    'url': '/api/dailyreport',
    'method': 'POST',
    'payload': {
      'section': 'dailyreport'
    }
  },
  'header': pageHeaders,
  'sidebar': sidebar,
  'hooks': {
    'load': 'handleFilterLoad'
  },
  'rows': [
    {
      'name': 'pageHeader',
      'type': 'FieldsRow',
      'className': 'pageHeader clearfix d-block py-3',
      'fields': [
        {
          'name': 'pageHeading',
          'type': 'HeadingField',
          'headingType': 'h3',
          'className': 'pageHeader-heading',
          'heading': 'Daily Report'
        },
        {
          'name': 'filters',
          'type': 'Filters',
          'mapApiData': {
            'data': filters
          }
        }
      ]
    },
    breadcrumb,
    {
      'name': 'realtime-row-1',
      'type': 'CardRow',
      'className': 'mt-3',
      'heading': 'Daily Repors',
      'cardClassName': 'col-md-12 p-0 mb-0',
      'bodyClass': 'p-0',
      'headerButtons': [
        {
          'name': 'exportToExcel',
          'type': 'exportToExcel',
          'icon': 'fa fa-file-excel-o',
          'fieldName': 'trendingVideosCard',
          'ignoreActiveClass': true,
          'fileName': 'trendingVideos'
        }
      ],
      'fields': [
        {
          'name': 'trendingVideos',
          'type': 'CardField',
          'subType': 'ChartField',
          'className': 'col-md-12 p-0 border-0',
          'chart': {
            'chartType': 'Table',
            'width': '100%',
            'height': '100%',
            'graph_id': 'trendingVideos',
            'options': {
              'width': '100%'
            },
            'classPrefix': 'svpTable',
            'className': 'svpTable'
          },
          'mapApiData': {
            'data': 'tableformatted'
          },
        }
      ]
    },
  ]
};
