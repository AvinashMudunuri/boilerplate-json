const pageHeaders = require('../common/pageHeader');
const sidebar = require('../common/sidebar');
const headerRow = require('./rows/header');
const breadcrumb = require('../common/breadcrumb');
const topWidgets = require('./rows/topWidgets');
const playbackSummary = require('./rows/playbackSummary');
const avgLoadTime = require('./rows/avgLoadTime');
const countryWiseDist = require('./rows/countryWiseDist');
const dashboardLastRow = require('./rows/dashboardLastRow');

module.exports = {
  'name': 'dashboard',
  'api': {
    'url': '/api/dashboard',
    'method': 'POST',
    'payload': {
      'section': 'videoplays,autoplayback,adsfillrate,adblocked,playindia,playbacksummary,sdkloadtime,playbacktime,startuptime,top-countries,top-browsers,top-sections,top-videos'
    } 
  },
  'header': pageHeaders,
  'sidebar': sidebar,
  'hooks': {
    'load': 'handleFilterLoad'
  },
  'rows': [
    headerRow,
    breadcrumb,
    topWidgets,
    playbackSummary,
    avgLoadTime,
    countryWiseDist,
    dashboardLastRow
  ]
};
