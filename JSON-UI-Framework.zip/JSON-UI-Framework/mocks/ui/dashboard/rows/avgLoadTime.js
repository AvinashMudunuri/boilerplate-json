module.exports = {
  'name': 'avgLoadTime',
  'type': 'CardRow',
  'className': 'mt-3',
  'heading': 'Average Load Time',
  'cardClassName': 'col-md-12 p-0 mb-0',
  'fields': [
    {
      'name': 'sdk',
      'type': 'InfoCard',
      'heading': 'SDK',
      'color': 'skyBlue',
      'mapApiData': {
        'value': 'sdkavgLT'
      },
    },
    {
      'name': 'videoManifist',
      'type': 'InfoCard',
      'heading': 'Video Manifest',
      'color': 'skyBlue',
      'mapApiData': {
        'value': 'vavgPB'
      },
    },
    {
      'name': 'playBackStart',
      'type': 'InfoCard',
      'heading': 'Playback Start',
      'color': 'skyBlue',
      'mapApiData': {
        'value': 'vavgLT'
      },
    }
  ]
};
