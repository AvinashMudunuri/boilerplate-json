module.exports = {
  'name': 'countryWiseDist',
  'type': 'CardRow',
  'className': 'mt-3',
  'heading': 'Country Wise distribution',
  'cardClassName': 'col-md-12 p-0 mb-0',
  'bodyClass': 'row m-0',
  'fields': [
    {
      'name': 'countryMap',
      'type': 'CardField',
      'subType': 'ChartField',
      'chart': {
        'chartType': 'GeoChart',
        'width': '100%',
        'height': '400px',
        'graph_id': 'countryMap',
        'className': 'chartBody',
        'buttons': [
          {
            'name': 'showTable',
            'type': 'exportToJPG',
            'icon': 'icon-share-alt',
            'fieldName': 'countryMap'
          }
        ]
      },
      'className': 'col-md-8 p-0 border-0',
      'mapApiData': {
        'data': 'countrywiseMapData'
      }
    },
    {
      'name': 'countryMapTable',
      'type': 'CardField',
      'subType': 'ChartField',
      'chart': {
        'chartType': 'Table',
        'width': '100%',
        'height': '400px',
        'graph_id': 'countryMapTable',
        'classPrefix': 'realTimeTable',
        'className': 'realTimeTable',
      },
      'className': 'col-md-4 border-0',
      'mapApiData': {
        'data': 'countrywiseMapData'
      }
    },
  ]
};
