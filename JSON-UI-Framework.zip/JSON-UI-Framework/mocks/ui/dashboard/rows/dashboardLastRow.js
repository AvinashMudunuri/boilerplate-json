module.exports = {
  'name': 'dashboardLastRow',
  'type': 'FieldsRow',
  'className': 'mt-3',
  'fields': [
    {
      'name': 'videoList',
      'type': 'CardField',
      'subType': 'ChartField',
      'chart': {
        'chartType': 'Table',
        'width': '100%',
        'height': '100%',
        'graph_id': 'videoList',
        'classPrefix': 'dashBoardTable',
        'className': 'dashBoardTable'
      },
      'className': 'p-0 col-md-4 col-12 br-sm-0',
      'bodyClass': 'p-0',
      'mapApiData': {
        'data': 'videoWiseViewCount'
      }
    },
    {
      'name': 'sectionsList',
      'type': 'CardField',
      'subType': 'ChartField',
      'chart': {
        'chartType': 'Table',
        'width': '100%',
        'height': '100%',
        'graph_id': 'sectionsList',
        'classPrefix': 'dashBoardTable',
        'className': 'dashBoardTable'
      },
      'className': 'p-0 col-md-4 col-12 br-sm-0',
      'bodyClass': 'p-0',
      'mapApiData': {
        'data': 'sectionWiseViewCount'
      }
    },
    {
      'name': 'browserList',
      'type': 'CardField',
      'subType': 'ChartField',
      'chart': {
        'chartType': 'Table',
        'width': '100%',
        'height': '100%',
        'graph_id': 'browserList',
        'classPrefix': 'dashBoardTable',
        'className': 'dashBoardTable'
      },
      'className': 'p-0 col-md-4 col-12',
      'bodyClass': 'p-0',
      'mapApiData': {
        'data': 'browserWiseViewCount'
      }
    },
  ]
};
