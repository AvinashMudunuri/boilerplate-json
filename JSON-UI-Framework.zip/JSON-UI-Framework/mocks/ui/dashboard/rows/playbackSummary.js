module.exports = {
  'name': 'playBackSummaryRow',
  'type': 'CardRow',
  'className': 'mt-3',
  'heading': 'Playback Summary',
  'cardClassName': 'col-md-12 p-0 mb-0',
  'headerButtons': [
    {
      'name': 'showTable',
      'type': 'toggleField',
      'icon': 'fa fa-table',
      'fieldName': 'playBackSummaryTable',
      'group': 'toggle',
    },
    {
      'name': 'showChart',
      'type': 'toggleField',
      'icon': 'fa fa-line-chart',
      'fieldName': 'playBackSummaryLine',
      'group': 'toggle',
      'active': true
    }
  ],
  'fields': [
    {
      'name': 'playBackSummaryLine',
      'type': 'CardField',
      'subType': 'ChartField',
      'className': 'col-md-12 p-0 border-0 mb-0',
      'chart': {
        'chartType': 'LineChart',
        'width': '100%',
        'height': '350px',
        'graph_id': 'playBackSummaryLine',
        'className': 'chartBody',
        'buttons': [
          {
            'name': 'showTable',
            'type': 'exportToJPG',
            'icon': 'icon-share-alt',
            'fieldName': 'playBackSummaryLine'
          }
        ]
      },
      'mapApiData': {
        'data': 'vdsAdsTable'
      }
    },
    {
      'name': 'playBackSummaryTable',
      'type': 'CardField',
      'subType': 'ChartField',
      'className': 'col-md-12 p-0 border-0 mb-0',
      'chart': {
        'chartType': 'Table',
        'width': '100%',
        'height': '350px',
        'graph_id': 'playBackSummaryTable',
        'classPrefix': 'svpTable',
        'className': 'svpTable'
      },
      'mapApiData': {
        'data': 'vdsAdsTable',
        'hide': true
      },
    }
  ]
};
