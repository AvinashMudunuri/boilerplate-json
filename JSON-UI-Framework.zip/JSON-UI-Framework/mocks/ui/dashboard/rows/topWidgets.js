module.exports = {
  'name': 'topWidgets',
  'type': 'FieldsRow',
  'className': 'mt-3',
  'fields': [
    {
      'name': 'videoPlays',
      'type': 'ProgressCard',
      'color': 'green',
      'iconClass': 'icon-control-play',
      'heading': 'Video-Plays',
      'mapApiData': {
        'percent': 'vprP.p|largeNumber',
        'value': 'vp|largeNumber',
        'total': 'vv|largeNumber'
      },
      'matchCondition': {
        'apiData|vprP.p': '*number'
      },
      'progressHTML': {
        'upper': '&nbsp;',
        'lower': '<b class="color-green">#percent#%</b> of #total# Video Views'
      }
    },
    {
      'name': 'autoPlayBack',
      'type': 'ProgressCard',
      'color': 'skyBlue',
      'iconClass': 'icon-disc',
      'heading': 'Auto Playback',
      'mapApiData': {
        'percent': 'vparP.p|largeNumber',
        'value': 'vpa|largeNumber',
        'total': 'vp|largeNumber'
      },
      'matchCondition': {
        'apiData|vparP.p': '*number'
      },
      'progressHTML': {
        'upper': '&nbsp;',
        'lower': '<b class="color-skyBlue">#percent#%</b> of #total# Video Plays'
      },
    },
    {
      'name': 'adFillRate',
      'type': 'ProgressCard',
      'color': 'yellow',
      'iconClass': 'icon-cursor',
      'heading': 'Ad Fill Rate',
      'mapApiData': {
        'percent': 'asrP.p',
        'value': 'asrP.p|percent',
        'total': 'ac|largeNumber',
        'pre': 'aspreroll|largeNumber',
        'post': 'aspostroll|largeNumber',
        'otherValue': 'vpii|largeNumber',
      },
      'progressHTML': {
        'upper': '<div class="float-left">Pre: <b class="color-yellow">#pre#</b></div><div class="float-right">Pre: <b class="color-yellow">#post#</b></div>',
        'lower': '<b class="color-yellow">#otherValue#</b> of #total# Ad Calls'
      }
    },
    {
      'name': 'adBlocker',
      'type': 'ProgressCard',
      'color': 'red',
      'iconClass': 'icon-ban',
      'heading': 'Ad Blocker',
      'mapApiData': {
        'percent': 'vvwabrP.p',
        'value': 'vvwabrP.p|percent',
        'otherValue': 'vpii|largeNumber',
        'total': 'vv|largeNumber'
      },
      'progressHTML': {
        'upper': '&nbsp;',
        'lower': '<b class="color-red">#otherValue#</b> of #total# Video Views'
      }
    },
    {
      'name': 'playedInIndia',
      'type': 'ProgressCard',
      'color': 'lightGreen',
      'iconClass': 'icon-compass',
      'heading': 'Played in India',
      'mapApiData': {
        'percent': 'vpiirP.p',
        'value': 'vpiirP.p|percent',
        'otherValue': 'vpii|largeNumber',
        'total': 'vv|largeNumber'
      },
      'progressHTML': {
        'upper': '&nbsp;',
        'lower': '<b class="color-lightGreen">#otherValue#</b> of #total# Video Plays'
      }
    }
  ]
};
