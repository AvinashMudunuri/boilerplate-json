const globals = {
  homePage: '/dashboard',
  logingPage: '/login',
  pages: [
    {
      pageId: '/login',
      title: 'Slike:Login',
    },
    {
      pageId: '/dashboard',
      title: 'Dashboard',
      auth: true
    },
    {
      pageId: '/407',
    },
    {
      pageId: '/503'
    },
    {
      pageId: '/dailyreport',
      title: 'Daily Reports',
      auth: true
    },
    {
      pageId: '/realtime',
      title: 'Daily Reports',
      auth: true
    },
    {
      pageId: '/vendorreport',
      title: 'Vendor Reports',
      auth: true
    },
    {
      pageId: '/sydicationreport',
      title: 'Sydication Reports',
      auth: true
    }    
  ]
};

module.exports = globals;
