const api = [
  {
    route: '/ui/*',
    responses: [
      {
        request: { method: 'GET' },
        response: (ctx, action) => {
          ctx.type = 'application/json';
          ctx.body = JSON.stringify(require(`./${action}`));
        }
      }
    ]
  }
];

module.exports = api;
