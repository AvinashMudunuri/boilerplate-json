module.exports = {
  'name': 'login',
  'rows': [
    {
      'name': 'pageHeader',
      'type': 'PageHeader',
      'homeLink': '/login',
      'hideProfile': true,
      'hideNavToggler': true,
      'logoClass': 'mx-auto'
    },
    {
      'name': 'loginbox',
      'type': 'LoginBlock',
      'heading': 'Login',
      'subHeading': 'Sign in to your account',
      'submitAction': 'loginSubmit',
      'fields': [
        {
          'name': 'userInput',
          'type': 'InputField',
          'label': 'Username',
          'iconClass': 'icon-user',
          'className': 'mb-3',
          'dom': {
            'type': 'text',
            'placeholder': 'Username'
          },
          'formFieldName': 'login',
          'isFormField': true,
          'validation': {
            'type': 'text'
          }
        },
        {
          'name': 'passwordInput',
          'type': 'InputField',
          'label': 'Password',
          'iconClass': 'icon-lock',
          'className': 'mb-4',
          'dom': {
            'type': 'password',
            'placeholder': 'Password'
          },
          'formFieldName': 'password',
          'isFormField': true,
          'validation': {
            'type': 'text'
          }
        },
        {
          'name': 'loginSubmit',
          'type': 'ButtonField',
          'label': 'Sign in',
          'buttonType': 'primary',
          'action': {
            'type': 'rowSubmit',
            'reValidateRow': true
          }
        }
      ]
    }
  ]
};
