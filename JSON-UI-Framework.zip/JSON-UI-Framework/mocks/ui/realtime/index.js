const pageHeaders = require('../common/pageHeader');
const sidebar = require('../common/sidebar');
const headerRow = require('./rows/header');
const breadcrumb = require('../common/breadcrumb');
const topWidget = require('./rows/topWidget');
const realtimeRow1 = require('./rows/realtimeRow1');
const realtimeRow2 = require('./rows/realtimeRow2');
const realtimeRow3 = require('./rows/realtimeRow3');
const dockPanel = require('./rows/dockPanel');

module.exports = {
  'name': 'realtime',
  'api': {
    'url': '/api/realtime',
    'method': 'POST',
    'payload': {
      'section': 'playbacktime,activeUsers,startuptime,lastonemin,top-videos,top-products,top-countries,top-browsers,live,top-sections,top-platforms,videoplays'
    } 
  },
  'autoRefresh': {
    'interval': '5000'
  },
  'header': pageHeaders,
  'sidebar': sidebar,
  'hooks': {
    'load': 'handleFilterLoad'
  },
  'rows': [
    headerRow,
    breadcrumb,
    topWidget,
    realtimeRow1,
    realtimeRow2,
    realtimeRow3,
    dockPanel
  ]
};
