module.exports = {
  'name': 'dockedPanel',
  'type': 'FieldsRow',
  'dock': true,
  'ignoreRowClass': true,
  'style': {
    'width': '140px',
    'height': '140px'
  },
  'fields': [
    {
      'name': 'dockedActiveUsers',
      'type': 'FocusedCard',
      'subHeading': 'ACTIVE USERS',
      'iconClass': 'icon-people',
      'ignoreCardClass': true,
      'className': 'text-white b-xs-1 br-sm-0 card-dock m-0',
      'style': {
        'backgroundColor': '#66bb6a',
        'border': 0
      },
      'mapApiData': {
        'value': 'users.value'
      }
    }
  ]
};
