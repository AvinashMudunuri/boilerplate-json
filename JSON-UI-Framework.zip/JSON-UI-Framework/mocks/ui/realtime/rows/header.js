const filters = require('../../../api/filters');
module.exports = {
  'name': 'pageHeader',
  'type': 'FieldsRow',
  'className': 'pageHeader clearfix d-block py-3',
  'fields': [
    {
      'name': 'pageHeading',
      'type': 'HeadingField',
      'headingType': 'h3',
      'className': 'pageHeader-heading',
      'heading': 'Realtime'
    },
    {
      'name': 'filters',
      'type': 'Filters',
      'ignoreNextUpdate': true,
      'mapApiData': {
        'data': filters
      }
    }
  ]
};
