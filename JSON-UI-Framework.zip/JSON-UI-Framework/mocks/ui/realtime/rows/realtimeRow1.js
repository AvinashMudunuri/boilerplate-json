module.exports = {
  'name': 'realtime-row-1',
  'type': 'FieldsRow',
  'className': 'mt-2',
  'fields': [
    {
      'name': 'userPerSecond',
      'type': 'CardField',
      'subType': 'ChartField',
      'className': 'col-md-4 p-0 b-xs-1 br-sm-0',
      'heading': 'New User Per Second',
      'headerButtons': [
        {
          'name': 'showTable',
          'type': 'toggleChart',
          'icon': 'fa fa-table',
          'chartConfig': 'table',
          'group': 'toggle'
        },
        {
          'name': 'showChart',
          'type': 'toggleChart',
          'icon': 'fa fa-line-chart',
          'chartConfig': 'graph',
          'group': 'toggle',
          'active': true
        }
      ],
      'activeChartConfig': 'graph',
      'chartConfig': {
        'graph': {
          'chartType': 'ColumnChart',
          'width': '100%',
          'height': '300px',
          'graph_id': 'userPerSecondGraph',
          'options': {
            'legend': 'none',
            'animation': {
              'duration': 1000,
              'easing': 'out'
            },
            'colors': ['#71a28a'],
            'hAxis': {
              'slantedText': true,
              'slantedTextAngle': 45 
            }
          },
          'className': 'chartBody',
          'buttons': [
            {
              'name': 'showTable',
              'type': 'exportToJPG',
              'icon': 'icon-share-alt',
              'fieldName': 'userPerSecond'
            }
          ]
        },
        'table': {
          'chartType': 'Table',
          'graph_id': 'userPerSecondTable',
          'width': '100%',
          'height': '300px',
          'classPrefix': 'realTimeTable',
          'className': 'realTimeTable mt-2',
          'options': {
            'chartArea': {
              'width': '100%',
              'height': '300px'
            }
          }
        }
      },
      'mapApiData': {
        'data': 'usersbymin|googleChartData'
      }
    },
    {
      'name': 'trendingVideos',
      'type': 'CardField',
      'subType': 'ChartField',
      'className': 'col-md-4 p-0 b-xs-1 br-sm-0',
      'bodyClass': 'p-0',
      'heading': 'Trending Videos',
      'headerButtons': [
        {
          'name': 'showTable',
          'type': 'toggleChart',
          'icon': 'fa fa-table',
          'chartConfig': 'table',
          'group': 'toggle',
          'active': true          
        },
        {
          'name': 'showChart',
          'type': 'toggleChart',
          'icon': 'fa fa-line-chart',
          'chartConfig': 'graph',
          'group': 'toggle'
        }
      ],
      'activeChartConfig': 'table',
      'chartConfig': {
        'table': {
          'chartType': 'Table',
          'graph_id': 'trendingVideos',
          'width': '100%',
          'height': '100%',
          'classPrefix': 'realTimeTable',
          'className': 'realTimeTable mt-2',
          'options': {
            'chartArea': {
              'width': '100%',
              'height': '100%'
            }
          }
        },
        'graph': {
          'chartType': 'PieChart',
          'width': '100%',
          'height': '300px',
          'graph_id': 'trendingVideos',
          'options': {
            'animation': {
              'duration': 1000,
              'easing': 'inAndOut'
            }
          },
          'className': 'chartBody',
          'buttons': [
            {
              'name': 'showTable',
              'type': 'exportToJPG',
              'icon': 'icon-share-alt',
              'fieldName': 'trendingVideos'
            }
          ]
        }
      },
      'mapApiData': {
        'data': 'trendingvid|googleChartData'
      },
    },
    {
      'name': 'topProducts',
      'type': 'CardField',
      'subType': 'ChartField',
      'className': 'col-md-4 p-0',
      'heading': 'Top Products',
      'chart': {
        'chartType': 'PieChart',
        'width': '100%',
        'height': '300px',
        'graph_id': 'topProducts',
        'options': {
          'animation': {
            'duration': 1000,
            'easing': 'inAndOut'
          }
        },
        'className': 'chartBody',
        'buttons': [
          {
            'name': 'showTable',
            'type': 'exportToJPG',
            'icon': 'icon-share-alt',
            'fieldName': 'topProducts'
          }
        ]
      },
      'mapApiData': {
        'data': 'product.buckets|googleChartData'
      }
    }
  ]
};
