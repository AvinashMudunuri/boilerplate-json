module.exports = {
  'name': 'realtime-row-2',
  'type': 'FieldsRow',
  'className': 'mt-2',
  'fields': [
    {
      'name': 'countryMap',
      'type': 'CardField',
      'heading': 'Video Playes in Country',
      'headerClass': 'd-md-none',
      'subType': 'ChartField',
      'chart': {
        'chartType': 'GeoChart',
        'width': '100%',
        'height': '400px',
        'graph_id': 'countryMap',
        'className': 'chartBody',
        'buttons': [
          {
            'name': 'showTable',
            'type': 'exportToJPG',
            'icon': 'icon-share-alt',
            'fieldName': 'countryMap',
            'mapsApiKey': 'AIzaSyCoCoLw5tyt_hrzfICsj7F-Sss-PaePxdg'
          }
        ]
      },
      'className': 'col-md-5 p-0 b-xs-1 br-sm-0',
      'mapApiData': {
        'data': 'country.buckets|googleChartData'
      }
    },
    {
      'name': 'countryMapTable',
      'type': 'CardField',
      'subType': 'ChartField',
      'heading': 'Video Playes in Country',
      'headerClass': 'd-md-none',
      'heading': 'Video Playes in Country',
      'chart': {
        'chartType': 'Table',
        'width': '100%',
        'height': '400px',
        'graph_id': 'countryMapTable',
        'classPrefix': 'realTimeTable',
        'className': 'realTimeTable',
      },
      'className': 'col-md-3 p-0 b-xs-1 br-sm-0 bl-sm-0',
      'mapApiData': {
        'data': 'country.buckets|googleChartData'
      }
    },
    {
      'name': 'browsers',
      'type': 'CardField',
      'subType': 'ChartField',
      'className': 'col-md-4 p-0',
      'heading': 'Browsers',
      'chart': {
        'chartType': 'PieChart',
        'width': '100%',
        'height': '400px',
        'graph_id': 'browsers'
      },
      'mapApiData': {
        'data': 'browser.buckets|googleChartData'
      }
    }
  ]
};
