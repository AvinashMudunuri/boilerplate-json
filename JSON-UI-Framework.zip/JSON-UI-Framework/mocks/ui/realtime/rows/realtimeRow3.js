module.exports = {
  'name': 'realtime-row-3',
  'type': 'FieldsRow',
  'className': 'mt-2',
  'fields': [
    {
      'name': 'liveStream',
      'type': 'CardField',
      'subType': 'ChartField',
      'heading': 'TOP LIVE STREAMS',
      'chart': {
        'chartType': 'PieChart',
        'width': '100%',
        'height': '200px',
        'graph_id': 'liveStream'
      },
      'className': 'col-md-4 p-0 b-xs-1 br-sm-0',
      'mapApiData': {
        'data': 'live.buckets|googleChartData'
      }
    },
    {
      'name': 'topSections',
      'type': 'CardField',
      'subType': 'ChartField',
      'heading': 'TOP SECTION',
      'chart': {
        'chartType': 'PieChart',
        'width': '100%',
        'height': '200px',
        'graph_id': 'topSections'
      },
      'className': 'col-md-4 p-0 b-xs-1 br-sm-0',
      'mapApiData': {
        'data': 'sections.buckets|googleChartData'
      }
    },
    {
      'name': 'topPlatforms',
      'type': 'CardField',
      'subType': 'ChartField',
      'heading': 'TOP PLATFORMS',
      'chart': {
        'chartType': 'PieChart',
        'width': '100%',
        'height': '200px',
        'graph_id': 'topPlatforms'
      },
      'className': 'col-md-4 p-0',
      'mapApiData': {
        'data': 'platform.buckets|googleChartData'
      }
    }
  ]
};
