module.exports = {
  'name': 'topWidgets',
  'type': 'FieldsRow',
  'className': 'mt-3 mb-xs-4 mb-md-1',
  'fields': [
    {
      'name': 'activeUsers',
      'type': 'FocusedCard',
      'subHeading': 'ACTIVE USERS',
      'iconClass': 'icon-people',
      'className': 'col text-white border-0 mb-xs-0 mb-md-4',
      'style': {
        'backgroundColor': '#66bb6a',
        'border': 0
      },
      'mapApiData': {
        'value': 'googletable.activeUsers.value'
      },
      'matchCondition': {
        'apiData|googletable.activeUsers.value': '*number'
      }
    },
    {
      'name': 'videoViews',
      'type': 'FocusedCard',
      'subHeading': 'VIDEO VIEWS',
      'iconClass': 'icon-social-youtube',
      'className': 'col text-white border-0 mb-xs-0 mb-md-4',
      'style': {
        'backgroundColor': '#37474f',
      },
      'mapApiData': {
        'value': 'googletable.videoplays.value'
      },
      'matchCondition': {
        'apiData|googletable.videoplays.value': '*number'
      }
    },
    {
      'name': 'playbackTime',
      'type': 'FocusedCard',
      'subHeading': 'PLAYBACK TIME',
      'iconClass': 'icon-clock',
      'className': 'col text-white border-0 mb-xs-0 mb-md-4',
      'style': {
        'backgroundColor': '#1e88e5',
      },
      'mapApiData': {
        'value': 'googletable.playbacktime.value|intoSeconds'
      },
      'matchCondition': {
        'apiData|googletable.playbacktime.value': '*number'
      }
    },
    {
      'name': 'startUpTime',
      'type': 'FocusedCard',
      'subHeading': 'STARTUP TIME',
      'iconClass': 'icon-clock',
      'className': 'col text-white border-0 mb-xs-0 mb-md-4',
      'style': {
        'backgroundColor': '#f57c00',
      },
      'mapApiData': {
        'value': 'googletable.startuptime.value|intoSeconds'
      },
      'matchCondition': {
        'apiData|googletable.startuptime.value': '*number'
      }
    }
  ]
};
