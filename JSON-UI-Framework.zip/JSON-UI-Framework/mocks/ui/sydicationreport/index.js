const pageHeaders = require('../common/pageHeader');
const sidebar = require('../common/sidebar');
const filters = require('../../api/filters');
module.exports = {
  'name': 'sydicationreport',
  'api': {
    'url': '/api/sydicationreport',
    'method': 'GET'
  },
  'header': pageHeaders,
  'sidebar': sidebar,
  'rows': [
    {
      'name': 'pageHeader',
      'type': 'FieldsRow',
      'className': 'pageHeader clearfix d-block py-3',
      'fields': [
        {
          'name': 'pageHeading',
          'type': 'HeadingField',
          'headingType': 'h3',
          'className': 'pageHeader-heading',
          'heading': 'PUBLISHED PRODUCT (SYNDICATION)'
        }
      ]
    },
    {
      'name': 'summary',
      'type': 'CardRow',
      'className': 'mt-3',
      'heading': 'Summary',
      'cardClassName': 'col-md-12 p-0 mb-0',
      'bodyClass': 'p-0',
      'fields': [
        {
          'name': 'summaryList',
          'type': 'CardField',
          'subType': 'ChartField',
          'chart': {
            'chartType': 'Table',
            'width': '100%',
            'height': '100%',
            'graph_id': 'summaryList',
            'classPrefix': 'svpTable',
            'className': 'svpTable'
          },
          'className': 'p-0 col-12 border-0',
          'bodyClass': 'p-0',
          'mapApiData': {
            'data': 'summary'
          }
        }
      ]
    },
    {
      'name': 'detailRow',
      'type': 'CardRow',
      'className': 'mt-3',
      'heading': 'DETAILED REPORT',
      'cardClassName': 'col-md-12 p-0 mb-0',
      'bodyClass': 'p-0',
      'fields': [
        {
          'name': 'detailRowList',
          'type': 'CardField',
          'subType': 'ChartField',
          'chart': {
            'chartType': 'Table',
            'width': '100%',
            'height': '100%',
            'graph_id': 'detailRowList',
            'classPrefix': 'svpTable',
            'className': 'svpTable'
          },
          'className': 'p-0 col-12 border-0',
          'bodyClass': 'p-0',
          'mapApiData': {
            'data': 'summary'
          }
        }
      ]
    },
    {
      'name': 'exportToExcel',
      'type': 'FieldsRow',
      'className': 'row-btmStick clearfix',
      'dock': false,
      'ignoreRowClass': true,
      'fields': [
        {
          'name': 'calendarSelect',
          'type': 'DownloadExcelWrapper',
          'buttonLabel': 'Download CSV'
        }
      ]
    }
  ]
};
