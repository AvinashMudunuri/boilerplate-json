const pageHeaders = require('../common/pageHeader');
const sidebar = require('../common/sidebar');
const filters = require('../../api/filters');
const breadcrumb = require('../common/breadcrumb');
module.exports = {
  'name': 'vendorreport',
  'api': {
    'url': '/api/vendorreport',
    'method': 'POST',
    'payload': {
      'section': 'vendorSummary'
    }
  },
  'header': pageHeaders,
  'sidebar': sidebar,
  'hooks': {
    'load': 'handleFilterLoad'
  },
  'rows': [
    {
      'name': 'pageHeader',
      'type': 'FieldsRow',
      'className': 'pageHeader clearfix d-block py-3',
      'fields': [
        {
          'name': 'pageHeading',
          'type': 'HeadingField',
          'headingType': 'h3',
          'className': 'pageHeader-heading',
          'heading': 'Video Report'
        },
        {
          'name': 'filters',
          'type': 'Filters',
          'mapApiData': {
            'data': filters
          }
        }
      ]
    },
    breadcrumb,
    {
      'name': 'vendorSummary',
      'type': 'CardRow',
      'className': 'mt-3',
      'heading': 'Summary',
      'cardClassName': 'col-md-12 p-0 mb-0',
      'bodyClass': 'p-0',
      'headerButtons': [
        {
          'name': 'exportToExcel',
          'type': 'exportToExcel',
          'icon': 'fa fa-file-excel-o',
          'fieldName': 'summaryListCard',
          'ignoreActiveClass': true,
          'fileName': 'vendorSummary'
        }
      ],
      'fields': [
        {
          'name': 'summaryList',
          'type': 'CardField',
          'subType': 'ChartField',
          'chart': {
            'chartType': 'Table',
            'width': '100%',
            'height': '100%',
            'graph_id': 'vendorSummary',
            'classPrefix': 'svpTable',
            'className': 'svpTable'
          },
          'className': 'p-0 col-12 border-0',
          'bodyClass': 'p-0',
          'mapApiData': {
            'data': 'report'
          }
        }
      ]
    },
    {
      'name': 'dateWiseReport',
      'type': 'CardRow',
      'className': 'mt-3',
      'heading': 'Date Wise Detailed Report',
      'cardClassName': 'col-md-12 p-0 mb-0',
      'bodyClass': 'p-0',
      'headerButtons': [
        {
          'name': 'exportToExcel',
          'type': 'exportToExcel',
          'icon': 'fa fa-file-excel-o',
          'fieldName': 'dateWiseReportListCard',
          'ignoreActiveClass': true,
          'fileName': 'dateWiseReport'
        }
      ],
      'fields': [
        {
          'name': 'dateWiseReportList',
          'type': 'CardField',
          'subType': 'ChartField',
          'chart': {
            'chartType': 'Table',
            'width': '100%',
            'height': '100%',
            'graph_id': 'dateWiseReport',
            'classPrefix': 'svpTable',
            'className': 'svpTable'
          },
          'className': 'p-0 col-12 border-0',
          'bodyClass': 'p-0',
          'mapApiData': {
            'data': 'vendorreport'
          }
        }
      ]
    }
  ]
};
