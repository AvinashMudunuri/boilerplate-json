import { FILTER_CHANGE, TOGGLE_CHILD_FILTER, SEARCH_FILTER, REMOVE_FILTER_BREADCRUMB, CLEAR_FILTER_SELECTION, APPLY_FILTER_SELECTION, DATE_FILTER_SELECTION, TOGGLE_ASIDE_MENU } from './constants';


function filterChange(data) {
  return {
    type: FILTER_CHANGE,
    ...data
  };
}

function toggleChildFilter(data) {
  return {
    type: TOGGLE_CHILD_FILTER,
    ...data
  };
}

function searchFilter(data) {
  return {
    type: SEARCH_FILTER,
    ...data
  };
}

function removeFilterBreadcrumb(data) {
  return {
    type: REMOVE_FILTER_BREADCRUMB,
    ...data
  };
}

function clearFilterSelection(data) {
  return {
    type: CLEAR_FILTER_SELECTION,
    ...data
  };
}

function applyFilterSelection(data) {
  return {
    type: APPLY_FILTER_SELECTION,
    ...data
  };
}

function dateFilterSelection(data) {
  return {
    type: DATE_FILTER_SELECTION,
    ...data
  };
}

function toggleAsideMenu(data) {
  return {
    type: TOGGLE_ASIDE_MENU,
    ...data
  };
}

export default {
  filterChange,
  toggleChildFilter,
  searchFilter,
  removeFilterBreadcrumb,
  clearFilterSelection,
  applyFilterSelection,
  dateFilterSelection,
  toggleAsideMenu
};
