import page from './page';
import user from './user';
import filter from './filter';

export default {
  ...page,
  ...user,
  ...filter
};
