import { AUTO_REFRESH, LOCATION_CHANGE, EXPORT_TO_JPG, TOGGLE_FIELD, EXPORT_TO_EXCEL, TOGGLE_CHART, DOWNLOAD_CSV } from './constants';

function autoRefresh(data) {
  return {
    type: AUTO_REFRESH,
    ...data
  };
}

function locationChange(data) {
  return {
    type: LOCATION_CHANGE,
    ...data
  };
}

function exportToJPG(data) {
  return {
    type: EXPORT_TO_JPG,
    ...data
  };
}

function toggleField(data) {
  return {
    type: TOGGLE_FIELD,
    ...data
  };
}

function exportToExcel(data) {
  return {
    type: EXPORT_TO_EXCEL,
    ...data
  };
}

function toggleChart(data) {
  return {
    type: TOGGLE_CHART,
    ...data
  };
}

function downloadCSV(data) {
  return {
    type: DOWNLOAD_CSV,
    ...data
  };
}

export default {
  autoRefresh,
  locationChange,
  exportToJPG,
  toggleField,
  exportToExcel,
  toggleChart,
  downloadCSV
};
