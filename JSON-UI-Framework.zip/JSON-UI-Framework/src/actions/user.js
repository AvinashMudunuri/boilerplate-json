import { UPDATE_FIELD_DATA, LOGIN_SUBMIT, ROW_SUBMIT, LOGOUT } from './constants';

function updateField(data) {
  return {
    type: UPDATE_FIELD_DATA,
    ...data
  };
}

function loginSubmit(data) {
  return {
    type: LOGIN_SUBMIT,
    data: {
      ...data
    }
  };
}

function rowSubmit(data) {
  return {
    type: ROW_SUBMIT,
    ...data
  };
}

function logout(data) {
  return {
    type: LOGOUT,
    ...data
  };
}

export default {
  updateField,
  loginSubmit,
  rowSubmit,
  logout
};
