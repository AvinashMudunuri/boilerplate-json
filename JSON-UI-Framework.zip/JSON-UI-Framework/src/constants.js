export const APP_BASE_URL = '';

export const ErrorCode = {
  SOMETHING_WRONG: 999
};

export const Endpoint = {
  LOGIN_API: '/api/user/login',
  LOGIN_CHECK: '/api/user/login',
  MOCK_UI: '/api/ui'
};

export const NOT_FOUND_PAGE = '/407';

export const NOT_ACCESSIBLE_PAGE = '/login';

export const cookieExpiry = 365;
export const cookieName = 'token';

export const MobileMinWidth = 320;
export const MobileMaxWidth = 767;

export const TabletMinWidth = 768;
export const TabletMaxWidth = 1023;

export const DesktopMinWidth = 1024;

export const Messages = {
  API_BROKEN: 'Api call is broken, fix the Api service',
  INVALID_FORM_VALUES: 'Invalid Form Fields',
  LOGIN_FAILED: 'Login Failed'
};

export const API_BASE_PATH = 'http://localhost:3000';

export const DEFAULT_CHART_COLORS = [
  '#3366CC',
  '#DC3912',
  '#FF9900',
  '#109618',
  '#990099',
  '#3B3EAC',
  '#0099C6',
  '#DD4477',
  '#66AA00',
  '#B82E2E',
  '#316395',
  '#994499',
  '#22AA99',
  '#AAAA11',
  '#6633CC',
  '#E67300',
  '#8B0707',
  '#329262',
  '#5574A6',
  '#3B3EAC',
];
