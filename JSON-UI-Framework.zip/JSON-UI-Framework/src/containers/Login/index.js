/* eslint-disable */
import React from 'react';
import Driver from '../driver';

const driver = Driver();

const Login = () => {
  return driver.render(
    <div className="app login">
      {driver.renderRows()}
    </div>
  );
};

export default driver.create(Login);
