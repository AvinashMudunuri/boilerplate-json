import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Container } from 'reactstrap';
import classNames from 'classnames';
import Driver from '../driver';
import PageHeader from '../../rows/PageHeader';
import Sidebar from '../../rows/Sidebar';

const driver = Driver();

class RealTime extends Component {
  constructor(props) {
    super(props);
    this.intervalStarted = false;
    this.interval = undefined;
  }
  componentWillReceiveProps() {
    const { page: { autoRefresh } = {}, actions } = this.props;
    if (!this.intervalStarted && autoRefresh) {
      this.interval = setInterval(actions.autoRefresh, autoRefresh.interval);
      this.intervalStarted = true;
    }
  }
  componentWillUnmount() {
    this.interval && clearInterval(this.interval);
  }
  render() {
    const { page: { header, sidebar, loading }, user: { openAsideFilter } } = this.props;
    return (
      <div className="app header-fixed sidebar-fixed dashboard sidebar-hidden">
        {header && <PageHeader {...header} />}
        <div className="app-body">
          <Sidebar {...sidebar} />
          <main className={classNames('main', { 'aside-open': openAsideFilter })}>
            <Container fluid>
              {driver.renderRows()}
            </Container>
          </main>
        </div>
        {loading && <div className="lmask" />}
      </div>
    );
  }
}

RealTime.propTypes = {
  page: PropTypes.object,
  actions: PropTypes.object,
  user: PropTypes.object
};

export default driver.create(RealTime);
