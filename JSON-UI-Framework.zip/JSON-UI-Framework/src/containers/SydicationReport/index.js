/* eslint-disable */
import React from 'react';
import PropTypes from 'prop-types';
import { Container } from 'reactstrap';
import classNames from 'classnames';
import Driver from '../driver';
import PageHeader from '../../rows/PageHeader';
import Sidebar from '../../rows/Sidebar';

const driver = Driver();

const SydicationReport = ({ page: { header, sidebar, loading } = {}, user: { openAsideFilter } }) => {
  return (
    <div className="app header-fixed sidebar-fixed syndicationReport sidebar-hidden">
      {header && <PageHeader actionFire={driver.actionFire()} {...header} />}
      <div className="app-body">
        <Sidebar {...sidebar} />
        <main className={classNames('main')}>
          <Container fluid>
            {driver.renderRows()}
          </Container>
        </main>
      </div>
      {loading && <div className='lmask'></div>}
    </div>
  );
}

SydicationReport.propTypes = {
  page: PropTypes.object,
  actions: PropTypes.object
};

export default driver.create(SydicationReport);
