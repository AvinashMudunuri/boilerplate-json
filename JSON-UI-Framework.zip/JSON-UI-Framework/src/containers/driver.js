import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import RowDriver from '../rows/rowDriver';
import actions from '../actions';

export default () => {
  const map = {
    page: {},
    user: {},
    actions: null
  };
  const actionFire = config => ({ type, ...actionData }) => {
    if (map.actions[type]) {
      map.actions[type]({
        config,
        actionData
      });
    }
  };
  const rowDriver = RowDriver(actionFire);
  const render = (children, Wrapper = 'div') => <Wrapper>{children}</Wrapper>;
  const mapStateToProps = function mapStateToProps(state) {
    map.page = state.page;
    map.user = state.user;
    rowDriver.updateMap(state);
    return {
      page: map.page,
      user: map.user
    };
  };
  const mapDispatchToProps = (dispatch) => {
    map.actions = bindActionCreators({
      ...actions
    }, dispatch);
    return {
      actions: map.actions
    };
  };
  const create = Container => connect(mapStateToProps, mapDispatchToProps)(Container);
  return {
    render,
    create,
    actionFire,
    ...rowDriver
  };
};
