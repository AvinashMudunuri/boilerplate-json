import Dashboard from './Dashboard';
import Login from './Login';
import DailyReport from './DailyReport';
import RealTime from './RealTime';
import VendorReport from './VendorReport';
import SydicationReport from './SydicationReport';

export default {
  Dashboard,
  Login,
  DailyReport,
  RealTime,
  VendorReport,
  SydicationReport
};
