/* eslint-disable */
import React from 'react';
import classNames from 'classnames';
import { Button } from 'reactstrap';

const ButtonField = ({ label, action, className, containerClass, buttonType, actionFire, disabled = false}) => {
  const buttonClicked = () => {
    if(disabled === false && action){
      actionFire({
        ...action
      });
    }
  };
  return (
    <div className={classNames(containerClass)}>
      <Button color={buttonType} className={classNames(className)} onClick={buttonClicked} disabled={disabled}>{ label }</Button>
    </div>
  );
};

export default ButtonField;
