/* eslint-disable */
import React, { Component } from "react";
import propTypes from "prop-types";
import classNames from "classnames";
import { Link } from "react-router-dom";
import { Card, CardBody, CardHeader } from "reactstrap";
import Chart from "../../components/Chart";
import isEqual from "lodash.isequal";

class ChartField extends Component {
  shouldComponentUpdate(nextProps) {
    const { fieldData: { data } = {}, chart } = this.props;
    const { fieldData: { data: newData } = {}, chart: newChart } = nextProps;
    this.buttonClick = this.buttonClick.bind(this);
    return !(isEqual(data, newData) && isEqual(chart, newChart));
  }
  buttonClick(config) {
    const { actionFire } = this.props;
    actionFire({
      ...config
    });
  }
  render() {
    const { fieldData: { data } = {}, chart } = this.props;
    let cssClassNames = undefined;
    if (chart.chartType === 'Table') {
      const chartClassPrefix = chart.classPrefix || 'slkTable';
      cssClassNames = {
        'headerRow': `${chartClassPrefix}-headerRow`,
        'tableRow': `${chartClassPrefix}-tableRow`,
        'oddTableRow': `${chartClassPrefix}-oddTableRow`,
        'selectedTableRow': `${chartClassPrefix}-selectedTableRow`,
        'hoverTableRow': `${chartClassPrefix}-hoverTableRow`,
        'headerCell': `${chartClassPrefix}-headerCell`,
        'tableCell': `${chartClassPrefix}-tableCell`,
        'rowNumberCell': `${chartClassPrefix}-rowNumberCell`
      };
    }
    const config = {
      ...chart,
      'options': {
        cssClassNames,
        ...chart.options
      },
      data
    };
    return (
      <div className={classNames(chart.className)}>
        <Chart {...config} />
        {chart.buttons && <div className="chartButtons">
          {chart.buttons.map((button, index) => {
            return (
              <span key={index} className={classNames('chartButtonsIcon')} onClick={() => this.buttonClick(button)}>
                <i className={button.icon}></i>
              </span>
            )
          })}
        </div>}
      </div>
    );
  }
};

export default ChartField;
