/* eslint-disable */
import React, { Component } from 'react';
import classNames from 'classnames';

const Checkbox = ({ id, className, label, action, actionFire, hide, selected = false, value }) => {
  const onChange = () => {
    if (action) {
      actionFire({
        ...action
      });
    }
  };
  if (hide === true) {
    return null;
  }
  return (
    <div id={id} className={classNames('checkbox', className)}>
      <label>
        <input type="checkbox" checked={selected} value={value} onChange={onChange} />
        <span className="cr"><i className="cr-icon fa fa-check"></i></span>
        {label}
      </label>
    </div>
  );
}

export default Checkbox;
