/* eslint-disable */
import React, { Component } from 'react';
import classNames from 'classnames';
import 'react-dates/initialize';
import moment from 'moment';
import { DateRangePicker } from 'react-dates';
import 'react-dates/lib/css/_datepicker.css';
import ButtonField from '../ButtonField';
import { isMobile } from '../../utils';

class DownloadExcelWrapper extends Component {
  constructor(props) {
    super(props);
    let focusedInput = null;
    this.state = {
      focusedInput,
      startDate: null,
      endDate: null,
      dateSelected: false
    };

    this.onDatesChange = this.onDatesChange.bind(this);
    this.onFocusChange = this.onFocusChange.bind(this);
  }
  onDatesChange({ startDate, endDate }) {
    const dateSelected = startDate !== null && endDate !== null;
    this.setState({ startDate, endDate, dateSelected });
  }
  onFocusChange(focusedInput) {
    this.setState({ focusedInput });
  }
  render() {
    const { focusedInput, startDate, endDate } = this.state;
    const { className, buttonLabel, actionFire } = this.props;
    const orientation = isMobile() ? 'vertical': 'horizontal';
    return (
      <div className="downloadExcelWrapper clearfix">
        <div className="downloadExcelWrapper-cal">
          <DateRangePicker
            startDate={startDate}
            endDate={endDate}
            startDatePlaceholderText="Start Date"
            endDatePlaceholderText="End Date"
            onDatesChange={this.onDatesChange}
            onFocusChange={this.onFocusChange}
            orientation={orientation}
            withPortal
            startDateId="startDate"
            endDateId="endDate"
            focusedInput={focusedInput}
          />
        </div>
        <ButtonField label={buttonLabel} actionFire={actionFire} containerClass="downloadExcelWrapper-btn" buttonType="primary" disabled={!this.state.dateSelected} action={{
          type: 'downloadCSV',
          dateRange: `${startDate}|${endDate}`
        }} />
      </div>
    );
  }
};

export default DownloadExcelWrapper;
