/* eslint-disable */
import React from 'react';
import classNames from 'classnames';
import { Button } from "reactstrap";

const FilterBreadcrumbs = ({ name, className, userData: { selectedFilters, filterSelected } = {}, actionFire }) => {
  if (!filterSelected) {
    return null;
  }
  const removeBreadcrumb = (filterKey, parentKey) => {
    actionFire({
      type: 'removeFilterBreadcrumb',
      key: filterKey,
      parentKey
    });
  };
  return (
    <div id={name} className={classNames('svpFiltersBreadcrumbs', className)}>
      {Object.keys(selectedFilters).map((filterKey) => {
        if(!selectedFilters[filterKey].label){
          return null;
        }
        return (
          <Button key={filterKey} size="sm" color="dark" className="svpFiltersBreadcrumbs-item rounded-right rounded-left mr-2 mb-2" onClick={() => { removeBreadcrumb(filterKey, selectedFilters[filterKey].parentKey) }}>
            {selectedFilters[filterKey].label}
          <i className="fa fa-times" aria-hidden="true"></i>
          </Button>
        );
      })}
    </div>
  );
};

export default FilterBreadcrumbs;
