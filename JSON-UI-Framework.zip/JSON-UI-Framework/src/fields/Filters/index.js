/* eslint-disable */
import React, { Component } from 'react';
import classNames from 'classnames';
import Types from './types';
import { getClosest } from '../../utils/dom';

class Filters extends Component {
  constructor(props) {
    super(props);
    this.hideAsideFilter = this.hideAsideFilter.bind(this);
  }

  componentDidMount() {
    document.addEventListener('mousedown', this.hideAsideFilter);
  }

  componentWillUnmount() {
    document.removeEventListener('mousedown', this.hideAsideFilter);
  }

  hideAsideFilter(e) {
    const breadCrumbContainer = getClosest(e.target, '.js-filterBreadcrumb');
    if (!this.container.contains(e.target) && !breadCrumbContainer) {
      const { actionFire, id, userData : { openAsideFilter } } = this.props;
      if(openAsideFilter){
        actionFire({
          type: 'toggleAsideMenu',
          key: 'filter'
        });
        window.dispatchEvent(new Event('resize'));
      }
    }
  }

  render() {
    const { className, fieldData: { data = {} } = {}, actionFire, userData: { filterSelected, filterApplied } = {} } = this.props;
    return (
      <div ref={(ele) => { this.container = ele; }} className={classNames('svpFilters clearfix', className)}>
        {data.children && data.children.map((key) => {
          const Field = Types[data[key].type];
          if (Field) {
            return <Field key={key} data={data} id={key} classPrefix="svpFilters" {...data[key]} actionFire={actionFire} filterSelected={filterSelected} filterApplied={filterApplied} />;
          } else {
            return null;
          }
        })}
      </div>
    );
  }
};

export default Filters;
