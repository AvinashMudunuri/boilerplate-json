/* eslint-disable */
import React, { Component } from 'react';
import classNames from 'classnames';
import { Button, Collapse, Card, CardBody, InputGroup, Input } from 'reactstrap';
import Types from './index';
import Checkbox from '../../Checkbox';

class Accordion extends Component {
  constructor(props) {
    super(props);
    this.toggle = this.toggle.bind(this);
    this.state = { collapse: false };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  render() {
    const { id, data, actionFire, label, childType, children, hide, search, value, parentKey, index = 1 } = this.props;
    if (hide) {
      return null;
    }
    let childIndex = index;
    if(children) {
      childIndex++;
    }
    return (
      <div className={classNames('svpFilters-acc', `svpFilters-acc-index${index}`, {'svpFilters-acc-active': children && !this.state.collapse})}>
        <div className={classNames('svpFilters-accHead', {'svpFilters-accHead-active': children && !this.state.collapse})} onClick={this.toggle}>
          <Checkbox id={`${id}Checkbox`} value={value} actionFire={actionFire} {...data[id]} action={
            {
              type: 'filterChange',
              key: id,
              parentKey
            }
          } />
          {children && <span className="svpFilters-accHead-i">
            <i className={classNames('fa', { 'fa-minus': !this.state.collapse, 'fa-plus': this.state.collapse })} aria-hidden="true"></i>
          </span>}
        </div>
        {!this.state.collapse && children && <div className="svpFilters-accCont">
          {children && children.map((key) => {
            const Field = Types[childType] || Types[data[key].type];
            const action = {
              type: 'filterChange',
              key,
              parentKey: id
            };
            if (Field) {
              return <Field key={key} id={key} {...data[key]} actionFire={actionFire} data={data} parentKey={id} action={action} index={childIndex} />;
            } else {
              return null;
            }
          })}
        </div>}
      </div>
    );
  }
}

export default Accordion;
