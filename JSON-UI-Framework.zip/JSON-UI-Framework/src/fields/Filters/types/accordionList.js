/* eslint-disable */
import React, { Component } from 'react';
import classNames from 'classnames';
import { Button, Collapse, Card, CardBody, InputGroup, Input } from 'reactstrap';
import Types from './index';
import Checkbox from '../../Checkbox';

class AccordionList extends Component {
  constructor(props) {
    super(props);
    this.toggle = this.toggle.bind(this);
    this.searchFilter = this.searchFilter.bind(this);
    this.state = { 
      collapse: false,
      searchTerm : ""
    };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  searchFilter(e) {
    const { id, actionFire } = this.props;
    const value = e.target.value;
    this.setState({
      searchTerm: value
    });
    actionFire({
      type: 'searchFilter',
      term: value,
      key: id
    });
  }

  render() {
    const { id, data, actionFire, label, childType, children, search } = this.props;
    return (
      <div className="svpFilters-accList">
        <div className={classNames('svpFilters-accListHead', {'svpFilters-accListHead-active': !this.state.collapse})} onClick={this.toggle}>
          <label>{label}</label>
          <span className="svpFilters-accListHead-i">
            <i className={classNames('fa', {'fa-minus': !this.state.collapse, 'fa-plus': this.state.collapse})} aria-hidden="true"></i>
          </span>
        </div>
        {!this.state.collapse && <div className="svpFilters-accListCont">
          {search && <div className="svpFilters-accListSearch">
            <InputGroup className="svpFilters-accListSearchG">              
              <Input placeholder="Search" className="svpFilters-accListSearchG-input" value={this.state.searchTerm} onChange={this.searchFilter} />
              <i className="icon-magnifier"></i>
            </InputGroup>
          </div>}
          {children && children.map((key) => {
            const Field = Types[childType] || Types[data[key].type];
            const action = {
              type: 'filterChange',
              key,
              parentKey: id
            };
            if (Field) {
              return <Field key={key} id={key} {...data[key]} actionFire={actionFire} data={data} parentKey={id} action={action} />;
            } else {
              return null;
            }
          })}
        </div>}
      </div>
    );
  }
}

export default AccordionList;
