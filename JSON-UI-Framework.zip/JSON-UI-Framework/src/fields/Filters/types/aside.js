/* eslint-disable */
import React, { Component } from 'react';
import classNames from 'classnames';
import { ButtonDropdown, DropdownToggle, DropdownMenu, DropdownItem, InputGroup, InputGroupAddon, Input, Button } from 'reactstrap';
import Types from './index';

class Aside extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false
    };
    this.toggleAsideFilter = this.toggleAsideFilter.bind(this);
    this.applyFilterSelection = this.applyFilterSelection.bind(this);
    this.clearFilterSelection = this.clearFilterSelection.bind(this);
  }
  toggleAsideFilter() {
    const { actionFire, id } = this.props;
    actionFire({
      type: 'toggleAsideMenu',
      key: id,
    });
    window.dispatchEvent(new Event('resize'));
  }
  applyFilterSelection() {
    const { actionFire } = this.props;
    actionFire({
      type: 'applyFilterSelection'
    });
  }
  clearFilterSelection() {
    const { actionFire } = this.props;
    actionFire({
      type: 'clearFilterSelection'
    });
  }
  render() {
    const { id, label, isAppFilter, children, childType, data, actionFire, selected = false, filterSelected, filterApplied } = this.props;
    return (
      <div id={id} className="svpFilters-menu">
        <Button className="svpFilters-menuBtn" onClick={this.toggleAsideFilter}>{label}</Button>
        <div className={classNames('svpFilters-aside', { 'svpFilters-aside-open': selected })}>
          {children && children.map((key) => {
            const Field = Types[childType] || Types[data[key].type];
            if (Field) {
              return <Field key={key} data={data} id={key} {...data[key]} actionFire={actionFire} />;
            } else {
              return null;
            }
          })}
          {selected && <div className="svpFilters-aside-footer">
            <Button color="primary" disabled={!filterSelected} onClick={this.applyFilterSelection}>Apply</Button>
            <Button color="primary" disabled={!(filterApplied || filterSelected)} onClick={this.clearFilterSelection}>Clear</Button>
            <Button color="primary" onClick={this.toggleAsideFilter}>Close</Button>
          </div>}
        </div>
      </div>
    );
  }
}

export default Aside;
