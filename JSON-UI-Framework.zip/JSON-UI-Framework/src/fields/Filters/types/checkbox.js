/* eslint-disable */
import React, { Component } from 'react';
import classNames from 'classnames';
import Types from './index';
import Checkbox from '../../Checkbox';

const CheckboxFilter = ({ id, label, action, actionFire, hide, selected, data, parentKey, value }) => {
  if (hide === true) {
    return null;
  }
  return (
    <div id={id} className={classNames('svpFilters-checkbox')}>
      <Checkbox id={`${id}Checkbox`} value={value} actionFire={actionFire} {...data[id]} action={
        {
          type: 'filterChange',
          key: id,
          parentKey
        }
      } />
    </div>
  );
}

export default CheckboxFilter;
