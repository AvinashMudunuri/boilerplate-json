/* eslint-disable */
import React, { Component } from 'react';
import classNames from 'classnames';
import moment from 'moment';
import { Button } from 'reactstrap';
import DateRangePicker from 'react-bootstrap-daterangepicker';

const DateRangeFilter = ({ id, className, label, actionFire, hide, selected = false, value }) => {
  const dateRange = value.split('|');
  const datePickerShow = () => {
    actionFire({
      type: 'hideAllFilterDropdown',
    });
  }

  const datePickerApply = (event, picker) => {
    actionFire({
      type: 'dateFilterSelection',
      value: `${picker.startDate.format('YYYY-MM-DD')}|${picker.endDate.format('YYYY-MM-DD')}`
    });
  }

  if (hide === true) {
    return null;
  }
  const ranges = {
    'Today': [moment(), moment()],
    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
  }
  return (
    <DateRangePicker startDate={moment(dateRange[0])} endDate={moment(dateRange[1])} ranges={ranges} opens="left" onShow={datePickerShow} onApply={datePickerApply}>
      <div id={id} className="svpFilters-menu">
        <Button className="svpFilters-menuBtn">
          <i className="fa fa-calendar" aria-hidden="true"></i>
          {value.split('|').join(' - ')}
          <i className="fa fa-angle-down" aria-hidden="true"></i>
        </Button>
      </div>
    </DateRangePicker>
  );
}

export default DateRangeFilter;
