import Aside from './aside';
import Checkbox from './checkbox';
import DateRange from './dateRange';
import AccordionList from './accordionList';
import Accordion from './accordion';
import SwitchContainer from './switchContainer';
import Switch from './switch';

export default {
  Aside,
  Checkbox,
  DateRange,
  AccordionList,
  SwitchContainer,
  Switch,
  Accordion
};
