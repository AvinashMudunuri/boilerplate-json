/* eslint-disable */
import React from 'react';
import classNames from 'classnames';

const Switch = ({ id, actionFire, selected, label, action }) => {
  const buttonClick = () => {
    if(action){
      actionFire({
        ...action
      });
    }
  }
  return (
    <span id={id} className={classNames('svpFilters-switchBtn', {'svpFilters-switchBtn-active': selected})} onClick={buttonClick}>
      {label}
    </span>
  );
};

export default Switch;
