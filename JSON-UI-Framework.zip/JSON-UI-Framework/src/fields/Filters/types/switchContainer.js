/* eslint-disable */
import React from 'react';
import Types from './index';

const SwitchContainer = ({ data, id, actionFire, childType, children }) => {
  return (
    <div id={id} className="svpFilters-switchCont">
      {children && children.map((key) => {
        const Field = Types[childType];
        const action = {
          type: 'filterChange',
          key,
          parentKey: id
        };
        if (Field) {
          return <Field key={key} id={key} {...data[key]} actionFire={actionFire} data={data} parentKey={id} action={action} />;
        } else {
          return null;
        }
      })}
    </div>
  );
};

export default SwitchContainer;
