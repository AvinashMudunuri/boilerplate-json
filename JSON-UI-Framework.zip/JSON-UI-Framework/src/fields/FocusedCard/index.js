/* eslint-disable */
import React from "react";
import propTypes from "prop-types";
import classNames from "classnames";
import { Link } from "react-router-dom";
import { CardBody } from "reactstrap";

const FocusedCard = ({ fieldData: { value } = {}, heading, className, iconClass, subHeading, style, ignoreCardClass }) => {
  return (
    <div className={classNames(className, {
      'card': !ignoreCardClass
    })} style={ style }>
      <CardBody>
        <div className="h1 text-muted text-right mb-2">
          <i className={classNames(iconClass)} />
        </div>
        <div className="h4 mb-0">{ heading || value }</div>
        <small className="text-muted text-uppercase font-weight-bold">
          {subHeading}
        </small>
      </CardBody>
    </div>
  );
};

FocusedCard.propTypes = {
  className: propTypes.string
};

export default FocusedCard;
