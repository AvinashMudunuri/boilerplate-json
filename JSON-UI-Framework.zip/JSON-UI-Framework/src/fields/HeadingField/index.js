/* eslint-disable */
import React from 'react';
import classNames from 'classnames';
import { Button } from 'reactstrap';

const HeadingField = ({ name, heading, headingType: HeadingType = 'h1', className }) => {
  return (
    <HeadingType id={name} className={classNames(className)}>{heading}</HeadingType>
  );
};

export default HeadingField;
