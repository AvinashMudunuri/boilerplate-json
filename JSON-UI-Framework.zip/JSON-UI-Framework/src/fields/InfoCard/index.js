/* eslint-disable */
import React from "react";
import propTypes from "prop-types";
import classNames from "classnames";

const InfoCard = ({ className, color, heading, fieldData: { value } = {}, responsive }) => {
  return (
    <div id={name} className={classNames('infoCard', className)}>
      <span className={`infoCard-line bg-${color}`}></span>
      <span className="infoCard-heading">{heading}</span>
      <span className="infoCard-value">{ value }</span>
    </div>
  );
};

InfoCard.propTypes = {
  className: propTypes.string
};

export default InfoCard;
