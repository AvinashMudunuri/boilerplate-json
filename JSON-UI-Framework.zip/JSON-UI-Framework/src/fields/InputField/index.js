/* eslint-disable */
import React from 'react';
import classNames from 'classnames';
import {FormGroup, Input, InputGroup, InputGroupAddon, FormFeedback } from 'reactstrap';

const InputField = ({ fieldData: { value = '', errorMsg, isValid } = {}, actionFire, className, iconClass, dom, name, formFieldName }) => {
  const inputChange = (value) => {
    actionFire({
      type: 'updateField',
      value
    });
  };
  return (
    <FormGroup>
      <InputGroup className={classNames(className)}>
        {iconClass && <InputGroupAddon><i className={iconClass}></i></InputGroupAddon>}
        <Input type="text" valid={isValid} value={value} name={formFieldName || name} {...dom} onChange={(e) => inputChange(e.target.value)} />
      </InputGroup>
      {isValid === false && <FormFeedback className="gm-block">{errorMsg}</FormFeedback>}
    </FormGroup>
  );
};

export default InputField;
