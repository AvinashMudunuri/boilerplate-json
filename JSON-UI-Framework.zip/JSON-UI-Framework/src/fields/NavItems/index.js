import React from 'react';
import propTypes from 'prop-types';
import classNames from 'classnames';
import { Link } from 'react-router-dom';
import { Nav, NavItem } from 'reactstrap';

const NavItems = ({ links, className, navItemClass }) => {
  if (!links || links.length === 0) {
    return null;
  }
  return (
    <Nav className={classNames(className)} navbar>
      {links.map(link => (
        <NavItem key={link.label} className={classNames(navItemClass)}>
          <Link className="nav-link" to={link.href}>{link.label}</Link>
        </NavItem>
      ))}
    </Nav>
  );
};

NavItems.propTypes = {
  links: propTypes.array,
  className: propTypes.string,
  navItemClass: propTypes.string
};

export default NavItems;
