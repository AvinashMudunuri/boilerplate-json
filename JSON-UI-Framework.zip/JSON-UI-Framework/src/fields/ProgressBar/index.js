/* eslint-disable */
import React from "react";
import classNames from "classnames";
import { dynamicString } from '../../utils';

function createMarkup(string, data) {
  return {__html: dynamicString(string, data)};
}

const ProgressBar = ({ color, className, progressHTML: { upper = '', lower= '' } = {}, data }) => {
  if (data) {
    return (
      <div className={classNames('progressBar', className)}>
        {upper && <div className="progressBar-txt clearfix text-muted" dangerouslySetInnerHTML={createMarkup(upper, data)} />}
        <div className={'progress-xs progress'}>
          <div className={`progress-bar bg-${color}`} role="progressbar" aria-valuenow={data.percent} aria-valuemin="0" aria-valuemax="100" style={{ 'width': `${data.percent}%` }}></div>
        </div>
        {lower && <div className="progressBar-txt clearfix text-muted" dangerouslySetInnerHTML={createMarkup(lower, data)} />}
      </div>
    );
  } else {
    return null;
  }
};

export default ProgressBar;
