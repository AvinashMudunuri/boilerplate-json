/* eslint-disable */
import React from "react";
import propTypes from "prop-types";
import classNames from "classnames";
import { Card, CardBody, Col } from "reactstrap";
import ProgressBar from '../ProgressBar';

const ProgressCard = ( { className, color, percent, iconClass, progressHTML, heading, fieldData = {} }) => {
  return (
    <Card className={classNames('progressCard', className)}>
        <CardBody className="px-3 py-3">
          <div className="progressCard-icon text-muted float-right">
            <i className={iconClass} />
          </div>
          <div className={`progressCard-heading color-${color}`}>{ heading }</div>
          <div className="progressCard-mainTxt">{ fieldData.value }</div>
          <ProgressBar color={color} percent={percent} className="progressCard-bar" progressHTML={progressHTML} data={fieldData}/>
        </CardBody>
      </Card>
  );
};

ProgressCard.propTypes = {
  className: propTypes.string
};

export default ProgressCard;
