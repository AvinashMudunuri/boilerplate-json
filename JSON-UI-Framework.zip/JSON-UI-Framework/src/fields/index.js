import NavbarBrand from 'reactstrap/lib/NavbarBrand';
import InputField from './InputField';
import ButtonField from './ButtonField';
import NavItems from './NavItems';
import FocusedCard from './FocusedCard';
import CardField from './CardField';
import ChartField from './ChartField';
import ProgressCard from './ProgressCard';
import InfoCard from './InfoCard';
import HeadingField from './HeadingField';
import Filters from './Filters';
import Checkbox from './Checkbox';
import FilterBreadcrumbs from './FilterBreadcrumbs';
import DownloadExcelWrapper from './DownloadExcelWrapper';

const fields = {
  NavbarBrand,
  InputField,
  ButtonField,
  NavItems,
  FocusedCard,
  CardField,
  ChartField,
  ProgressCard,
  InfoCard,
  HeadingField,
  Filters,
  Checkbox,
  FilterBreadcrumbs,
  DownloadExcelWrapper
};

export default fields;
export function updateFields(o) {
  Object.keys(o).forEach((key) => {
    fields[key] = o[key];
  });
}
