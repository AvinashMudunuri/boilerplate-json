/* eslint-disable */
import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route } from 'react-router-dom';
import registerServiceWorker from './registerServiceWorker';
import { applyMiddleware, createStore, compose } from 'redux';
import { Provider } from 'react-redux';
import createSagaMiddleware from 'redux-saga';
import { put} from 'redux-saga/effects';
import { init as initHistory } from './utils/history';

import routes from './routes';
import IndexReducer from './reducers/index';
import IndexSagas from './sagas/index';
import actions from './actions';
import './scss/style.scss';

const history = initHistory();

// Setup the middleware to watch between the Reducers and the Actions
const sagaMiddleware = createSagaMiddleware();

/* eslint-disable */
const composeSetup = process.env.NODE_ENV !== 'production' && typeof window === 'object' &&
  window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ?
  window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : compose
/* eslint-enable */

const store = createStore(
  IndexReducer,
  composeSetup(applyMiddleware(sagaMiddleware)), // allows redux devtools to watch sagas
);
// Begin our Index Saga
sagaMiddleware.run(IndexSagas);

history.listen((location) => {
  store.dispatch(actions.locationChange({
    payload: location
  }));
});

const App = () => (
  <Provider store={store}>
    <Router history={history}>
      <div className="svp">
        {routes.map((route, i) => <Route key={i} {...route} />)}
      </div>
    </Router>
  </Provider>
);

ReactDOM.render(<App />, document.getElementById('root'));
registerServiceWorker();

