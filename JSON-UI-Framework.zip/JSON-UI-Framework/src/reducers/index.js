/* eslint-disable */
import { combineReducers } from 'redux';
import { LOCATION_CHANGE} from '../actions/constants';
import page from './page';
import user from './user';
import queryString from 'query-string';

const routePayload = {
  hash: window.location.hash,
  pathname: window.location.pathname,
  search: window.location.search,
  query: queryString.parse(window.location.search),
};

// Initial routing state
const routeInitialState = {
  ...routePayload
};

const parseLocation = (payload) => {
  return {
    ...payload,
    query: queryString.parse(payload.search || window.location.search)
  };
};

/**
 * Merge route into the global application state
 */
function routeReducer(state = routeInitialState, action) {
  switch (action.type) {
    case LOCATION_CHANGE:
      return {
        ...state,
        ...parseLocation(action.payload),
      };
    default:
      return state;
  }
}

const IndexReducer = combineReducers({
  page,
  user,
  routing: routeReducer
});

export default IndexReducer;
