import { UPDATE_PAGE_DATA } from '../actions/constants';

const initialSate = {};

const updatePageData = (state, { data }) => ({
  ...state,
  ...data
});

const PageReducer = (state = initialSate, action) => {
  switch (action.type) {
    case UPDATE_PAGE_DATA:
      return updatePageData(state, action);
    default:
      return state;
  }
};

export default PageReducer;
