import { UPDATE_USER_DATA, UPDATE_FIELD_DATA } from '../actions/constants';

const initialSate = {};

const updateUserData = (state, { data }) => ({
  ...state,
  ...data
});

const updateFieldData = (state, { config, actionData }) => {
  const fieldName = config.name;
  const field = { ...state[fieldName] };
  field.value = actionData.value;
  return {
    ...state,
    [fieldName]: field
  };
};

const UserReducer = (state = initialSate, action) => {
  switch (action.type) {
    case UPDATE_USER_DATA:
      return updateUserData(state, action);
    case UPDATE_FIELD_DATA:
      return updateFieldData(state, action);
    default:
      return state;
  }
};

export default UserReducer;
