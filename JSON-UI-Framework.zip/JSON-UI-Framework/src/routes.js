import containers from './containers';

export default [
  {
    path: '/dashboard',
    component: containers.Dashboard
  },
  {
    path: '/login',
    component: containers.Login
  },
  {
    path: '/dailyreport',
    component: containers.DailyReport
  },
  {
    path: '/realtime',
    component: containers.RealTime
  },
  {
    path: '/vendorreport',
    component: containers.VendorReport
  },
  {
    path: '/sydicationreport',
    component: containers.SydicationReport
  }
];
