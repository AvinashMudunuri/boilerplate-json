/* eslint-disable */
import React, { Component } from "react";
import propTypes from "prop-types";
import classNames from "classnames";
import { Link } from "react-router-dom";
import { Card, CardBody, CardHeader, Row } from "reactstrap";
import Fields from '../index';

class CardRow extends Component {
  constructor(props) {
    super(props);
    let headerBtns = {};
    const { headerButtons } = this.props;
    if (headerButtons) {
      headerBtns = headerButtons.reduce((acc, btn) => {
        acc[btn.name] = { ...btn };
        acc[btn.name].active = acc[btn.name].active || false;
        return acc;
      }, {});
      this.state = {
        headerBtns
      };
      this.headerButtonClick = this.headerButtonClick.bind(this);
    }
  }

  headerButtonClick(config) {
    const { group } = config;
    const { headerBtns } = this.state;
    const { actionFire } = this.props;
    const state = {};
    if (group) {
      if(headerBtns[config.name].active){
        return;
      }
      Object.keys(headerBtns).forEach(key => {
        const btn = headerBtns[key];
        if (btn.group === group) {
          if (headerBtns[btn.name].active === true) {
            state[btn.name] = { ...btn };
            actionFire({
              ...state[btn.name]
            });
            state[btn.name].active = false;
          }
        }
      });
      actionFire({
        ...headerBtns[config.name]
      }); 
    }else {
      actionFire({
        ...headerBtns[config.name]
      }); 
    }
    this.setState({
      headerBtns: {
        ...headerBtns,
        ...state,
        [config.name]: {
          ...headerBtns[config.name],
          active: !headerBtns[config.name].active
        }
      }
    });
  };

  render() {
    const { heading, cardClassName, className, bodyClass, renderFields, headerButtons, actionFire } = this.props;
    return (
      <Row className={classNames(className)}>
        <Card className={classNames(cardClassName)}>
          {heading && <CardHeader>{heading}
            {headerButtons && <div className="cardHeaderBtn">
              {headerButtons.map((button, index) => {
                return (
                  <span key={index} className={classNames('cardHeaderBtnIcon', {
                    'active': !button.ignoreActiveClass && this.state.headerBtns[button.name].active
                  })} onClick={() => this.headerButtonClick(button)}>
                    <i className={button.icon}></i>
                  </span>
                )
              })}
            </div>}
          </CardHeader>}
          <CardBody className={classNames(bodyClass)}>
            {renderFields()}
          </CardBody>
        </Card>
      </Row>
    );
  }
};

CardRow.propTypes = {
  className: propTypes.string
};

export default CardRow;
