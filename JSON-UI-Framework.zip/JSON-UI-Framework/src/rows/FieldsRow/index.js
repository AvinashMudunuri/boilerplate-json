import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

class FieldsRow extends Component {
  constructor(prop) {
    super(prop);
    this.handlePageScroll = this.handlePageScroll.bind(this);
    if (prop.dock) {
      this.state = {
        showDockedRow: false
      };
      this.scrollEventRegistered = false;
    }
  }
  componentDidUpdate() {
    if (this.scrollEventRegistered === false) {
      document.addEventListener('scroll', this.handlePageScroll);
      this.scrollEventRegistered = true;
    }
  }
  componentWillUnmount() {
    if (this.scrollEventRegistered) {
      document.removeEventListener('scroll', this.handlePageScroll);
    }
  }
  handlePageScroll() {
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight / 2) {
      this.setState({
        showDockedRow: true
      });
    } else {
      this.setState({
        showDockedRow: false
      });
    }
  }
  render() {
    const { className, renderFields, dock, ignoreRowClass, style } = this.props;
    return (
      <div
        className={classNames(className, {
          'row': !ignoreRowClass,
          'row-dock': dock,
          'row-dock-show': this.state && this.state.showDockedRow
        })}
        style={style}>{renderFields()}
      </div>
    );
  }
}

FieldsRow.propTypes = {
  className: PropTypes.string,
  renderFields: PropTypes.func,
  dock: PropTypes.bool,
  ignoreRowClass: PropTypes.bool,
  style: PropTypes.object
};

export default FieldsRow;
