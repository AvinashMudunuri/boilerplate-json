/* eslint-disable */
import React from 'react';
import PropTypes from 'prop-types';
import {Container, Row, Col, CardGroup, Card, CardBody, Button, Input, InputGroup, InputGroupAddon, Alert} from 'reactstrap';

const LoginBlock = ({ rowData: { errorMsg } = {}, heading, subHeading, renderFields }) => {
  return (
    <div className="app-body flex-row align-items-center">
      <Container>
        <Row className="justify-content-center">
          <Col md="6">
            <CardGroup>
              <Card className="p-4">
                <CardBody>
                  <h1>{ heading }</h1>
                  <p className="text-muted">{ subHeading }</p>
                  { errorMsg && <Alert color="danger">
                    {errorMsg}
                  </Alert>
                  }
                  { renderFields() }
                </CardBody>
              </Card>
            </CardGroup>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

LoginBlock.propTypes = {
  renderFields: PropTypes.func,
  heading: PropTypes.string,
  subHeading: PropTypes.string
};

export default LoginBlock;
