/* eslint-disable */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classNames from "classnames";
import { NavLink, Link } from 'react-router-dom'
import {
  Nav,
  NavbarBrand,
  NavbarToggler,
  NavItem,
  Badge,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Dropdown
} from 'reactstrap';

class PageHeader extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.logout = this.logout.bind(this);
    this.state = {
      dropdownOpen: false
    };
  }

  toggle() {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen
    });
  }
  
  sidebarMinimize(e) {
    e.preventDefault();
    document.body.classList.toggle('sidebar-minimized');
  }

  mobileSidebarToggle(e) {
    e.preventDefault();
    document.body.classList.toggle('sidebar-mobile-show');
  }

  asideToggle(e) {
    e.preventDefault();
    document.body.classList.toggle('aside-menu-hidden');
  }
  
  logout() {
    this.props.actionFire({
      type: 'logout'
    })
  }

  render() {
    const { homeLink, navLinks, hideProfile = false, hideNavToggler = false, logoClass } = this.props;
    return (
      <header className="app-header navbar">
        {hideNavToggler === false && <NavbarToggler className="d-lg-none" onClick={this.mobileSidebarToggle}>
          <span className="navbar-toggler-icon"></span>
        </NavbarToggler>}
        <Link to={ homeLink } className={classNames('navbar-brand', logoClass)}></Link>
        {navLinks && navLinks.length && <Nav className="d-md-down-none" navbar>
          { navLinks.map((link) => <NavItem key={link.href} className="px-3">
            <NavLink className="nav-link" to={link.href} activeClassName="active">{link.label}</NavLink>
          </NavItem>)}
        </Nav>}
        {hideProfile === false && <Nav className="ml-auto" navbar>
          <Dropdown className="nav-item" isOpen={this.state.dropdownOpen} toggle={this.toggle}>
            <DropdownToggle nav>
              <img src={'img/avatar.png'} className="img-avatar" alt="admin@bootstrapmaster.com" />
            </DropdownToggle>
            <DropdownMenu right>
              <DropdownItem onClick={this.logout}><i className="fa fa-lock"></i> Logout</DropdownItem>
            </DropdownMenu>
          </Dropdown>
        </Nav>}
      </header>
    )
  }
};

PageHeader.propTypes = {
  renderFields: PropTypes.func
};

export default PageHeader;
