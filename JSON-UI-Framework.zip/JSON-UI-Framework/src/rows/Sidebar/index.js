/* eslint-disable */
import React from "react";
import propTypes from "prop-types";
import classNames from "classnames";
import { NavLink } from "react-router-dom";
import { Nav, NavItem } from "reactstrap";

const Sidebar = ({ navLinks, className }) => {
  return (
    <div className="sidebar">
      <nav className="sidebar-nav">
        <Nav>
          {navLinks && navLinks.length && navLinks.map((link, i) => {
            return (
              <NavItem key={i}>
                <NavLink className="nav-link" activeClassName="active" to={link.href}>{link.label}</NavLink>
              </NavItem>
            );
          })}
        </Nav>
      </nav>
    </div>
  );
};

export default Sidebar;
