import PageHeader from './PageHeader';
import LoginBlock from './LoginBlock';
import FieldsRow from './FieldsRow';
import CardRow from './CardRow';
import Sidebar from './Sidebar';

const rows = {
  PageHeader,
  LoginBlock,
  FieldsRow,
  CardRow,
  Sidebar
};

export default rows;
export function updateRows(o) {
  Object.keys(o).forEach((key) => {
    rows[key] = o[key];
  });
}
