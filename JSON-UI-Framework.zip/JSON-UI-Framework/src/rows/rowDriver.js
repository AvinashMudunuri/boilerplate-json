import React from 'react';
import Rows from './index';
import Fields from '../fields';
import { matchCondtion } from '../utils';

export default (actionFire) => {
  const map = {
    page: {},
    user: {}
  };

  const renderFields = (fields, rowName) => () => {
    const RowFields = [];
    fields.forEach((field) => {
      const fieldName = field.name;
      const Field = Fields[field.type];
      const fieldData = map.user[fieldName];
      let fieldProps = {
        key: fieldName,
        ...field
      };
      if (!field.ignoreCustomProp) {
        fieldProps = {
          ...fieldProps,
          fieldData,
          userData: map.user,
          actionFire: actionFire({
            ...field,
            rowName
          })
        };
      }
      fieldProps.ignoreCustomProp && delete fieldProps.ignoreCustomProp;
      if (Field) {
        if (fieldData && !fieldData.hide && matchCondtion(field.matchCondition, map.user)) {
          RowFields.push(
            <Field {...fieldProps} />
          );
        }
      }
    });
    if (RowFields.length) {
      return RowFields;
    }
  };

  const renderRows = () => {
    const { page: { rows }, user } = map;
    const PageRows = [];
    if (rows && rows.length) {
      rows.forEach((row) => {
        const Row = Rows[row.type];
        const rowData = user[row.name];
        if (Row && matchCondtion(row.matchCondition, map.user)) {
          PageRows.push(
            <Row
              key={row.name}
              className={row.className}
              rowData={rowData}
              {...row}
              actionFire={actionFire({
                ...row
              })}
              renderFields={renderFields(row.fields, row.name)} />
          );
        }
      });
    }
    if (PageRows.length) {
      return PageRows;
    }
  };

  const updateMap = ({ page, user }) => {
    map.page = page;
    map.user = user;
  };

  return {
    renderFields,
    updateMap,
    renderRows
  };
};
