/* eslint-disable */
import { takeLatest, select, put } from 'redux-saga/effects';
import { FILTER_CHANGE, UPDATE_USER_DATA, TOGGLE_CHILD_FILTER, SEARCH_FILTER, REMOVE_FILTER_BREADCRUMB, CLEAR_FILTER_SELECTION, APPLY_FILTER_SELECTION, UPDATE_PAGE_DATA, DATE_FILTER_SELECTION, TOGGLE_ASIDE_MENU } from '../actions/constants';
import { redirectTo } from '../utils/history';
import queryString from 'query-string';

function* filterChange({ actionData: { key, parentKey, ...rest } }) {
  const { user } = yield select(state => state);
  const { filters: { data } } = user;
  const filter = data[key];
  const { selectedFilters = {} } = user;
  let state = {
    [key]: {
      ...filter,
      selected: !filter.selected
    }
  };
  if (rest) {
    state[key] = {
      ...state[key],
      ...rest
    };
  }
  if (parentKey && (data[parentKey].childType === 'Switch')) {
    const parentFilter = data[parentKey];
    parentFilter.children.forEach((childKey) => {
      if (childKey !== key) {
        state[childKey] = { ...data[childKey] };
        state[childKey].selected = false;
      }
    });
  }

  Object.keys(state).forEach((filterKey) => {
    if (state[filterKey].selected) {
      selectedFilters[filterKey] = {
        label: state[filterKey].label,
        parentKey
      }
    } else {
      delete selectedFilters[filterKey];
    }
  });

  yield put({
    type: UPDATE_USER_DATA,
    data: {
      filters: {
        data: {
          ...data,
          ...state
        }
      },
      selectedFilters,
      filterSelected: Object.keys(selectedFilters).length > 0
    }
  });
}

function* toggleChildFilter({ actionData: { key, action, parentKey } }) {
  const { user } = yield select(state => state);
  const { filters: { data } } = user;
  const filter = data[key];
  const { selectedFilters = {} } = user;
  const state = filter.children.reduce((acc, childKey) => {
    if (!data[childKey].hide) {
      acc[childKey] = { ...data[childKey] }
      acc[childKey].selected = action === 'select';
    }
    return acc;
  }, {});

  Object.keys(state).forEach((filterKey) => {
    if (state[filterKey].selected) {
      selectedFilters[filterKey] = {
        label: state[filterKey].label,
        parentKey
      }
    } else {
      delete selectedFilters[filterKey];
    }
  });

  yield put({
    type: UPDATE_USER_DATA,
    data: {
      filters: {
        data: {
          ...data,
          ...state
        }
      },
      selectedFilters,
      filterSelected: Object.keys(selectedFilters).length > 0
    }
  });
}

function deepFilterSearch(key, term, data, finalData = {}, parentHide = true) {
  const filter = data[key];
  const { children } = filter;
  if (finalData[key]) {
    if (children) {
      let isAllChildHidden = true;
      children.forEach((childKey) => {
        deepFilterSearch(childKey, term, data, finalData, parentHide);
        if (finalData[childKey].hide === false) {
          isAllChildHidden = false;
        }
      });
      if (isAllChildHidden === false) {
        finalData[key].hide = false;
      }
      finalData[key].isAllChildHidden = isAllChildHidden;
    }
  } else {
    finalData[key] = { ...filter };
    finalData[key].hide = parentHide ? filter.label.toLowerCase().indexOf(term.toLowerCase()) === -1 : false;
    finalData[key].children && deepFilterSearch(key, term, data, finalData, finalData[key].hide);
  }
  return finalData;
}

function* searchFilter({ actionData: { key, term } }) {
  const { user } = yield select(state => state);
  const { filters: { data } } = user;
  const filter = data[key];
  const state = deepFilterSearch(key, term, data);
  yield put({
    type: UPDATE_USER_DATA,
    data: {
      filters: {
        data: {
          ...data,
          ...state
        }
      }
    }
  });
}

function* removeFilterBreadcrumb({ actionData: { key } }) {
  const { user } = yield select(state => state);
  const { filters: { data } } = user;
  const { selectedFilters = {} } = user;
  const state = {
    [key]: {
      ...data[key],
      selected: false
    }
  };
  delete selectedFilters[key];
  yield put({
    type: UPDATE_USER_DATA,
    data: {
      filters: {
        data: {
          ...data,
          ...state
        }
      },
      selectedFilters,
      filterSelected: Object.keys(selectedFilters).length > 0
    }
  });
}

function* clearFilterSelection({ actionData: { redirect = true } }) {
  const { user } = yield select(state => state);
  let { pathname } = yield select(({ routing }) => routing);
  const { filters: { data } } = user;
  let { selectedFilters = {} } = user;
  const state = {};
  Object.keys(selectedFilters).forEach((filterKey) => {
    state[filterKey] = { ...data[filterKey] };
    state[filterKey].selected = false;
  });
  selectedFilters = {};
  yield put({
    type: UPDATE_USER_DATA,
    data: {
      filters: {
        data: {
          ...data,
          ...state
        }
      },
      selectedFilters,
      filterSelected: false,
      filterApplied: false
    }
  });
  redirect === true && redirectTo(pathname);
}

function* applyFilterSelection() {
  const { user } = yield select(state => state);
  const { pathname } = yield select(({ routing }) => routing);
  let { query } = yield select(({ routing }) => routing);
  const { filters: { data }, selectedFilters = {} } = user;
  if(query.dateFilter) {
    query = {
      dateFilter: query.dateFilter
    };
  } else {
    query = {};
  }
  Object.keys(selectedFilters).forEach((filterKey) => {
    const { parentKey } = selectedFilters[filterKey];
    const { paramKey } = data[parentKey];
    const { value } = data[filterKey];
    query[paramKey] = query[paramKey] || [];
    if (data[parentKey].childType === 'RadioFilter') {
      query[paramKey] = [value];
    } else {
      query[paramKey].push(value);
    }
  });
  Object.keys(query).forEach((paramKey) => {
    query[paramKey] = typeof query[paramKey] === 'string' ? query[paramKey] : query[paramKey].join(',');
  });
  yield put({
    type: UPDATE_USER_DATA,
    data: {
      filterApplied: true
    }
  });
  redirectTo(`${pathname}?${queryString.stringify(query)}`);
}

function* dateFilterSelection({ actionData: { value } }) {
  let { pathname, search, query } = yield select(({ routing }) => routing);
  const { user } = yield select(state => state);
  const { filters: { data } } = user;
  query.dateFilter = value;
  query = queryString.stringify(query);
  const state = {
    dateFilter: {
      ...data.dateFilter,
      value
    }
  };
  yield put({
    type: UPDATE_USER_DATA,
    data: {
      filters: {
        data: {
          ...data,
          ...state
        }
      },
      filterApplied: true
    }
  });
  redirectTo(`${pathname}?${query}`);
}

function* toggleAsideMenu({ actionData: { key } }) {
  const { user } = yield select(state => state);
  const { filters, selectedFilters = {} } = user;
  const { data } = filters;
  const state = {
    [key]: {
      ...data[key],
      selected: !data[key].selected
    }
  };
  yield put({
    type: UPDATE_USER_DATA,
    data: {
      filters: {
        ...filters,
        data: {
          ...data,
          ...state
        }
      },
      openAsideFilter: !user.openAsideFilter
    }
  });
}

function* filterWatcher() {
  yield takeLatest(FILTER_CHANGE, filterChange);
  yield takeLatest(TOGGLE_CHILD_FILTER, toggleChildFilter);
  yield takeLatest(SEARCH_FILTER, searchFilter);
  yield takeLatest(REMOVE_FILTER_BREADCRUMB, removeFilterBreadcrumb);
  yield takeLatest(CLEAR_FILTER_SELECTION, clearFilterSelection);
  yield takeLatest(APPLY_FILTER_SELECTION, applyFilterSelection);
  yield takeLatest(DATE_FILTER_SELECTION, dateFilterSelection);
  yield takeLatest(TOGGLE_ASIDE_MENU, toggleAsideMenu);
}

export default filterWatcher;
