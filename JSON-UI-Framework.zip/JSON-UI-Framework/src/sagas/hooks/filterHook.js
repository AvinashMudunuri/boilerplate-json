import { isObjEmpty } from '../../utils';

function createSelectedFilters(filters, filterKey = null, parentKey, selectedFilters = {}) {
  const { children, selected, label } = filterKey === null ? filters : filters[filterKey];
  if (selected && filterKey !== 'dateFilter') {
    selectedFilters[filterKey] = {
      label,
      parentKey
    };
  }
  if (children) {
    children.forEach((childKey) => {
      createSelectedFilters(filters, childKey, filterKey, selectedFilters);
    });
  }
  return selectedFilters;
}

export function handleFilterLoad(pageData, userData) {
  const { filters: { data } = {} } = userData;
  const selectedFilters = createSelectedFilters(data);
  return {
    pageData,
    userData: {
      ...userData,
      selectedFilters,
      filterSelected: !isObjEmpty(selectedFilters)
    }
  };
}

