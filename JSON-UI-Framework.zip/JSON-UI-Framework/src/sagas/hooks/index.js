import { testHook } from './testHook';
import { handleFilterLoad } from './filterHook';

const hooks = {
  testHook,
  handleFilterLoad
};
export default key => hooks[key];
export function updateHooks(o) {
  Object.keys(o).forEach((key) => {
    hooks[key] = o[key];
  });
}
