import pageSaga from './page';
import userSaga from './user';
import { init } from './load';
import filterSaga from './filter';

export default function* IndexSaga() {
  yield [
    pageSaga(),
    userSaga(),
    init(),
    filterSaga()
  ];
}
