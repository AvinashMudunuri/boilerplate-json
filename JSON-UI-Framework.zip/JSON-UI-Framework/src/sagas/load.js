/* eslint-disable */
import { call, put, select } from 'redux-saga/effects';
import { fetchService, flatternObject, injectData, setPageTitle } from '../utils/index';
import { Endpoint, NOT_FOUND_PAGE, NOT_ACCESSIBLE_PAGE, Messages, APP_BASE_URL } from '../constants';
import { UPDATE_PAGE_DATA, UPDATE_USER_DATA } from '../actions/constants';
import { checkAuthorization } from '../utils/auth';
import sagaHook from './hooks/index';
import { forceRedirect } from '../utils/history';

export function* loadApi(api, isPageLoad) {
  const { query } = yield select(({ routing }) => routing );
  let paramObj = {
    ...api.payload,
    ...api.params,
    ...query,
    load: isPageLoad ? 1 : 0
  };
  api = {
    ...api,
    [api.method === 'POST' ? 'payload' : 'params'] : paramObj
  };
  const response = yield call(fetchService, api);
  return response;
}

export function* createUserData(pageData, response, ignoreNextUpdate) {
  const returnData = {};
  let apiData = {};
  if (response && response.success) {
    apiData = flatternObject(response);
  }
  const { rows } = pageData;
  const { user } = yield select((state) => state);
  rows.forEach((row) => {
    let rowObj = {};
    if (row.mapApiData) {
      rowObj = {
        ...injectData({}, row.mapApiData, apiData, response)
      };
      if(ignoreNextUpdate) {
        if(row.ignoreNextUpdate){
          rowObj = {
            ...user[row.name]
          };
        }
      }
    }
    returnData[row.name] = rowObj;
    const { fields } = row;
    fields && fields.forEach((field) => {
      let fieldObj = {};
      if (field.mapApiData) {
        fieldObj = {
          ...injectData({}, field.mapApiData, apiData, response)
        };
        if(ignoreNextUpdate) {
          if(field.ignoreNextUpdate){
            fieldObj = {
              ...user[field.name]
            };
          }
        }
      }
      fieldObj.rowName = row.name;
      returnData[field.name] = fieldObj;
    });
  });
  returnData.apiData = {
    ...apiData,
    raw: response
  };
  return returnData;
}

export function* updatePageData(data, pageConfig, global, ignoreNextUpdate, isPageLoad) {
  if(isPageLoad){
    yield put({
      type: UPDATE_PAGE_DATA,
      data: {
        loading: true
      }
    });
  }
  const { api } = data;
  const { hooks } = data;
  const { user } = yield select(state => state);
  let userData = {...user};
  let response = null;
  if (api) {
    response = yield loadApi(api, isPageLoad);
    if (!response && !response.success) {
      response = {
        success: false,
        errorMessage: pageConfig.errorMessage || Messages.API_BROKEN
      };
    }
  }
  let pageData = data;
  let newUserData = yield createUserData(pageData, response, ignoreNextUpdate, isPageLoad);
  userData = {
    ...userData,
    ...newUserData
  };
  if (hooks && hooks.load && !ignoreNextUpdate) {
    const hookData = yield sagaHook(hooks.load)(pageData, userData);
    pageData = {
      ...pageData,
      ...hookData.pageData
    };
    userData = {
      ...userData,
      ...hookData.userData
    };
  }

  yield put({
    type: UPDATE_PAGE_DATA,
    data: {
      ...global,
      ...pageData,
      loading: false
    }
  });

  yield put({
    type: UPDATE_USER_DATA,
    data: {
      ...userData
    }
  });
}

export function* init() {
  const pagePath = yield select(({ routing }) => routing.pathname);
  const global = yield call(fetchService, {
    url: `${Endpoint.MOCK_UI}/global`
  });
  if(pagePath.trim() === '' || pagePath.trim() === '/' || pagePath === APP_BASE_URL){
    const authResponse = yield checkAuthorization();
    authResponse == true ? forceRedirect(global.homePage) : forceRedirect(global.logingPage);
    return;
  }
  const { pages } = global;
  const matchPage = pages.filter(page => `${APP_BASE_URL}${page.pageId}` === pagePath);
  if (matchPage.length === 0) {
    forceRedirect(NOT_FOUND_PAGE);
    return;
  }
  if (matchPage[0].auth === true) {
    const authResponse = yield checkAuthorization();
    if(authResponse === false){
      forceRedirect(NOT_ACCESSIBLE_PAGE);
      return;
    }
  }
  if (matchPage[0].title) {
    setPageTitle(matchPage[0].title);
  }
  const data = yield call(fetchService, {
    url: `${Endpoint.MOCK_UI}${matchPage[0].pageId}`
  });
  yield updatePageData(data, matchPage[0], global, undefined, true);
}
