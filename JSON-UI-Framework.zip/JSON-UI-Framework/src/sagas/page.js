/* eslint-disable */
import { takeLatest, select, call, put } from 'redux-saga/effects';
import { fetchService, setPageTitle } from '../utils/index';
import { forceRedirect } from '../utils/history';
import { Endpoint, NOT_FOUND_PAGE, NOT_ACCESSIBLE_PAGE, Messages } from '../constants';
import { AUTO_REFRESH, UPDATE_USER_DATA, LOCATION_CHANGE, EXPORT_TO_JPG, TOGGLE_FIELD, EXPORT_TO_EXCEL, UPDATE_PAGE_DATA, TOGGLE_CHART, DOWNLOAD_CSV } from '../actions/constants';
import { checkAuthorization } from '../utils/auth';
import { updatePageData, createUserData, loadApi } from './load';
import { exportToJPG, exportToExcel } from '../utils/export';
import actions from '../actions';

function* locationChange() {
  yield put({
    type: UPDATE_PAGE_DATA,
    data: {
      loading: true
    }
  });
  const pagePath = yield select(({ routing }) => routing.pathname);
  const page = yield select(({ page }) => page);
  const { filterApplied } = yield select(({ user }) => user);
  const matchPage = page.pages.filter(page => page.pageId === pagePath);
  if (pagePath !== `/${page.name}`) {
    if(filterApplied){
      yield put(actions.clearFilterSelection({
        actionData: {
          redirect: false
        }
      }));
    }
    if (matchPage.length === 0) {
      forceRedirect(NOT_FOUND_PAGE);
    }
    if (matchPage[0].auth === true) {
      const authResponse = yield checkAuthorization();
      authResponse === false && forceRedirect(NOT_ACCESSIBLE_PAGE);
    }
    if (matchPage[0].title) {
      setPageTitle(matchPage[0].title);
    }
    const data = yield call(fetchService, {
      url: `${Endpoint.MOCK_UI}${pagePath}`
    });
    yield updatePageData(data, matchPage[0], {}, undefined, true);
  } else {
    yield updatePageData(page, matchPage[0], {}, true);
  }
  yield put({
    type: UPDATE_PAGE_DATA,
    data: {
      loading: false
    }
  });
}

function* reloadApiData() {
  const { page } = yield select(state => state);
  const { api } = page;
  let response = null;
  if (api) {
    response = yield loadApi(api);
    if (!response && !response.success) {
      response = {
        success: false,
        errorMessage: Messages.API_BROKEN
      };
    }
    const userData = yield createUserData(page, response, true);
    yield put({
      type: UPDATE_USER_DATA,
      data: {
        ...userData
      }
    });
  }
}

function exportJPG({ actionData }) {
  exportToJPG(actionData);
}


function* toggleField({ actionData }) {
  const { fieldName, active } = actionData;
  const { user } = yield select(state => state);
  yield put({
    type: UPDATE_USER_DATA,
    data: {
      ...user,
      [fieldName]: {
        ...user[fieldName],
        hide: active
      }
    }
  });
}

function exportExcel({ actionData }) {
  exportToExcel(actionData);
}

function* toggleChart ({ config, actionData }) {
  const { rows } = yield select(({ page }) => page);
  let selectedRow = undefined;
  let selectedRowIndex = undefined;
  let selectedField = {};
  let selectedFieldIndex = undefined;
  rows.every((element, index) => {
    if(element.name === config.rowName) {
      selectedRow = { ...element };
      selectedRowIndex = index;
      return false;
    } else {
      return true;
    }
  });
  if(selectedRow) {
    selectedRow.fields.every((element, index) => {
      if(element.name === config.name) {
        selectedField = {...element};
        selectedFieldIndex = index;
        return false;
      } else {
        return true;
      }
    });
    selectedField.activeChartConfig = actionData.chartConfig;
  }
  selectedRow.fields[selectedFieldIndex] = selectedField;
  const newRows = [...rows];
  newRows[selectedRowIndex] = selectedRow;
  yield put({
    type: UPDATE_PAGE_DATA,
    data: {
      rows: newRows
    }
  });
}

function* downloadCSV({ actionData }) {
  const response = yield call(fetchService, {
    url: '/api/downloadExcel',
    method: 'POST',
    payload: actionData
  });
}

function* pageWatcher() {
  yield takeLatest(LOCATION_CHANGE, locationChange);
  yield takeLatest(AUTO_REFRESH, reloadApiData);
  yield takeLatest(EXPORT_TO_JPG, exportJPG);
  yield takeLatest(TOGGLE_FIELD, toggleField);
  yield takeLatest(EXPORT_TO_EXCEL, exportExcel);
  yield takeLatest(TOGGLE_CHART, toggleChart);
  yield takeLatest(DOWNLOAD_CSV, downloadCSV);
}

export default pageWatcher;
