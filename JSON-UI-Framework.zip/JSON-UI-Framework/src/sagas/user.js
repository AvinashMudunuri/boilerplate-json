import { takeLatest, select, put, call } from 'redux-saga/effects';
import { ROW_SUBMIT, UPDATE_USER_DATA, LOGIN_SUBMIT, LOGOUT } from '../actions/constants';
import { validate } from '../utils/validate';
import { Messages, Endpoint, cookieName } from '../constants';
import actions from '../actions';
import { fetchService } from '../utils/index';
import { createAuthorization } from '../utils/auth';
import { eraseCookie } from '../utils/cookie';
import { forceRedirect } from '../utils/history';

function* rowSubmit({ config, actionData }) {
  const { rowName } = yield select(({ user }) => user[config.name]);
  const { user } = yield select(state => state);
  const row = yield select(({ page }) => page.rows.filter(rowObj => rowObj.name === rowName)[0]);
  let isRowValid = user[row.name].isValid;
  if (actionData.reValidateRow) {
    const fields = row.fields.filter(field => field.isFormField);
    const validateFields = {};
    fields.forEach((field) => {
      const fieldData = user[field.name];
      if (field.validation) {
        const validateObj = validate(field.label, fieldData.value, field.validation);
        validateFields[field.name] = {
          ...fieldData,
          ...validateObj
        };
      }
    });
    const tempObj = Object.keys(validateFields).filter(fieldName => validateFields[fieldName].isValid === false);
    isRowValid = tempObj.length === 0;
    validateFields[row.name] = {
      isValid: isRowValid,
      errorMsg: isRowValid ? '' : row.errorMsg || Messages.INVALID_FORM_VALUES
    };
    yield put({
      type: UPDATE_USER_DATA,
      data: {
        ...user,
        ...validateFields
      }
    });
  }
  if (isRowValid) {
    yield put(actions[row.submitAction]({ ...row }));
  }
}


function* loginSubmit({ data: row }) {
  const formFields = row.fields.filter(field => field.isFormField);
  const { user } = yield select(state => state);
  const payload = {
    type: 'login'
  };
  formFields.forEach((field) => {
    payload[field.formFieldName] = user[field.name].value;
  });
  const response = yield call(fetchService, {
    url: Endpoint.LOGIN_API,
    payload,
    method: 'POST'
  });
  if (response.success) {
    createAuthorization(response.uid);
    forceRedirect('/dashboard');
  } else {
    yield put({
      type: UPDATE_USER_DATA,
      data: {
        ...user,
        [row.name]: {
          errorMsg: Messages.LOGIN_FAILED
        }
      }
    });
  }
}

function logout() {
  eraseCookie(cookieName);
  forceRedirect('/login');
}

function* pageWatcher() {
  yield takeLatest(ROW_SUBMIT, rowSubmit);
  yield takeLatest(LOGIN_SUBMIT, loginSubmit);
  yield takeLatest(LOGOUT, logout);
}

export default pageWatcher;
