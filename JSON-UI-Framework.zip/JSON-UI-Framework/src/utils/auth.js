import { call } from 'redux-saga/effects';
import { cookieExpiry, Endpoint, cookieName } from '../constants';
import { createCookie, eraseCookie } from './cookie';
import { fetchService } from './index';

export function* checkAuthorization() {
  const response = yield call(fetchService, {
    url: Endpoint.LOGIN_CHECK,
    method: 'POST',
    payload: {
      type: 'loginCheck'
    }
  });
  if (response.success) {
    return true;
  } else {
    eraseCookie(cookieName);
    return false;
  }
}

export function createAuthorization(uid) {
  createCookie(cookieName, uid, cookieExpiry);
}
