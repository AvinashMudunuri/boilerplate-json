export function exportToJPG({ fieldName, fileName = 'image' }) {
  const ele = document.getElementById(fieldName);
  const svgEl = ele.getElementsByTagName('svg')[0];
  const canvas = document.createElement('canvas');
  canvas.width = svgEl.getBoundingClientRect().width;
  canvas.height = svgEl.getBoundingClientRect().height;
  const ctx = canvas.getContext('2d');
  const data = (new XMLSerializer()).serializeToString(svgEl);
  const DOMURL = window.URL || window.webkitURL || window;
  const img = new Image();
  const svgBlob = new Blob([data], { type: 'image/svg+xml;charset=utf-8' });
  const url = DOMURL.createObjectURL(svgBlob);

  img.onload = function imageOnLoad() {
    ctx.drawImage(img, 0, 0);
    DOMURL.revokeObjectURL(url);
    const imgURI = canvas
      .toDataURL('image/jpeg')
      .replace('image/jpeg', 'image/octet-stream');

    const evt = new MouseEvent('click', {
      view: window,
      bubbles: false,
      cancelable: true
    });
    const a = document.createElement('a');
    a.setAttribute('download', `${fileName}.jpg`);
    a.setAttribute('href', imgURI);
    a.setAttribute('target', '_blank');
    a.dispatchEvent(evt);
  };
  img.src = url;
}

export function downloadCsv(csv, filename) {
  // CSV FILE
  const csvFile = new Blob([csv], { type: 'text/csv' });

  // Download link
  const downloadLink = document.createElement('a');

  // File name
  downloadLink.download = `${filename}.csv`;

  // We have to create a link to the file
  downloadLink.href = window.URL.createObjectURL(csvFile);

  // Make sure that the link is not displayed
  downloadLink.style.display = 'none';

  // Add the link to your DOM
  document.body.appendChild(downloadLink);

  // Lanzamos
  downloadLink.click();
}

export function exportToExcel({ fieldName, fileName = 'file' }) {
  const field = document.getElementById(fieldName);
  const table = field.getElementsByTagName('table')[0];
  const csv = [];
  const rows = table.querySelectorAll('tr');

  for (let i = 0; i < rows.length; i++) {
    const row = [];
    const cols = rows[i].querySelectorAll('td, th');
    for (let j = 0; j < cols.length; j++) {
      row.push(cols[j].innerText);
    }
    csv.push(row.join(','));
  }
  // Download CSV
  downloadCsv(csv.join('\n'), fileName);
}
