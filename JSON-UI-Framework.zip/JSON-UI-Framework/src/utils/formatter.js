import NumAbbr from 'number-abbreviate';

const numAbbr = new NumAbbr([' K', ' M', ' B', ' T']);

export function largeNumber(number) {
  return numAbbr.abbreviate(number, 1);
}

export function percent(number) {
  return `${number}%`;
}

export function googleChartData(data) {
  if (data instanceof Array) {
    const returnData = [
      ['key', 'doc_count']
    ];
    data.forEach((obj) => {
      const tempArr = [];
      tempArr.push(obj.key);
      tempArr.push(obj.doc_count);
      returnData.push(tempArr);
    });
    return returnData;
  } else {
    return data;
  }
}

export function intoSeconds(value) {
  return `${value} Sec`;
}

export function timeConversion(millisec) {
  const seconds = (millisec / 1000).toFixed(1);

  const minutes = (millisec / (1000 * 60)).toFixed(1);

  const hours = (millisec / (1000 * 60 * 60)).toFixed(1);

  const days = (millisec / (1000 * 60 * 60 * 24)).toFixed(1);

  if (seconds < 60) {
    return `${seconds} Sec`;
  } else if (minutes < 60) {
    return `${minutes} Min`;
  } else if (hours < 24) {
    return `${hours} Hrs`;
  } else {
    return `${days} Days`;
  }
}

export default {
  largeNumber,
  percent,
  googleChartData,
  intoSeconds,
  value: value => value
};
