import createHistory from 'history/createBrowserHistory';
import { APP_BASE_URL } from '../constants';

let history = null;

export function init() {
  history = createHistory({
    basename: APP_BASE_URL
  });
  return history;
}

export function redirectTo(path) {
  history.push(`${APP_BASE_URL}${path}`);
}

export function forceRedirect(path) {
  window.location.href = `${APP_BASE_URL}${path}`;
}

export function goBack() {
  history.back();
}

export function getHistory() {
  return history;
}
