import { detect } from 'detect-browser';
import request from './request';
import { MobileMinWidth, MobileMaxWidth, TabletMinWidth, TabletMaxWidth, DesktopMinWidth, API_BASE_PATH } from '../constants';
import format from './formatter';

export function fetchService(config) {
  const url = new URL(`${API_BASE_PATH}${config.url}`);
  const options = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json; charset=UTF-8'
    },
    ...config
  };

  if (options.payload) {
    options.body = JSON.stringify(options.payload);
  }

  if (config.params && config.params !== null) {
    Object.keys(config.params).forEach(key => url.searchParams.append(key, config.params[key]));
  }

  return request(url, options);
}

export function getBrowser() {
  const browser = detect();
  return browser.name;
}

export function isMobile() {
  const viewportWidth = window.innerWidth;
  return viewportWidth >= MobileMinWidth && viewportWidth <= MobileMaxWidth;
}

export function isTablet() {
  const viewportWidth = window.innerWidth;
  return viewportWidth >= TabletMinWidth && viewportWidth <= TabletMaxWidth;
}

export function isDesktop() {
  const viewportWidth = window.innerWidth;
  return viewportWidth >= DesktopMinWidth;
}

export function flatternObject(obj) {
  const returnObj = {};
  Object.keys(obj).forEach((key) => {
    if (Object.prototype.toString.call(obj[key]) === '[object Object]') {
      const flatObject = flatternObject(obj[key]);
      Object.keys(flatObject).forEach((newKey) => {
        returnObj[`${key}.${newKey}`] = flatObject[newKey];
      });
    } else {
      returnObj[key] = obj[key];
    }
  });
  return returnObj;
}

export function deepSearchObject(key, obj) {
  const keyArray = key.indexOf('|') !== -1 ? key.split('|') : key.split('.');
  let value = obj;
  keyArray.every((tempKey) => {
    if (value[tempKey]) {
      value = value[tempKey];
      return true;
    } else {
      value = undefined;
      return false;
    }
  });
  return value;
}

export function injectData(baseObj = {}, keyObj, data, raw) {
  const obj = baseObj;
  Object.keys(keyObj).forEach((key) => {
    if (typeof keyObj[key] === 'string') {
      const dataKey = keyObj[key].split('|')[0];
      const formatter = keyObj[key].split('|')[1] || 'value';
      obj[key] = dataKey.indexOf('@') === 0 ? format[formatter](dataKey) : format[formatter](data[dataKey]) || format[formatter](deepSearchObject(dataKey, raw));
    } else {
      obj[key] = keyObj[key];
    }
  });
  return obj;
}

export function setPageTitle(title) {
  document.title = title;
}

export function dynamicString(string, data) {
  Object.keys(data).forEach((key) => {
    string = string.replace(new RegExp(`#${key}#`, 'g'), data[key]);
  });
  return string;
}

export function matchCondtion(matchObj, data) {
  if (matchObj) {
    let matched = false;
    Object.keys(matchObj).every((key) => {
      const value = deepSearchObject(key, data);
      let compareValue = matchObj[key];
      let typeOfCompare = false;
      if (typeof compareValue === 'string') {
        if (compareValue.indexOf('!') === 0) {
          compareValue = compareValue.substr(1);
        } else if (compareValue.indexOf('*') === 0) {
          compareValue = compareValue.substr(1);
          typeOfCompare = true;
        }
      }
      if (typeOfCompare && typeof value === compareValue) {
        matched = true;
        return false;
      }
      if (compareValue === value) {
        matched = true;
        return false;
      }
      return true;
    });
    return matched;
  } else {
    return true;
  }
}

export function isObjEmpty(obj) {
  return Object.keys(obj).length === 0 && obj.constructor === Object;
}
