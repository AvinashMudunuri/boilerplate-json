import 'whatwg-fetch';
import { ErrorCode } from '../constants';

/**
 * Parses the JSON returned by a network request
 */

function parseResponse(response) {
  const contentType = response.headers.get('content-type');
  if (contentType && contentType.indexOf('application/json') !== -1) {
    return response.json();
  } else {
    return response.text();
  }
}

/**
 * Check if a network request came back fine, and throws an error if not
 */

function checkStatus(response) {
  if (response.status >= 200 && response.status < 300) {
    return response;
  }
  const error = new Error(response.statusText);
  error.responseCode = ErrorCode.SOMETHING_WRONG;
  error.response = response;
  throw error;
}

/**
 * Request a URL, returning a Promise
 */
export default function request(url, options) {
  return fetch(url, options)
    .then(checkStatus)
    .then(parseResponse);
}
