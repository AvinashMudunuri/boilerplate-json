import { regexPatterns } from './regex';

const validator = {
  text: (label, value, { regex, errorMsg }) => {
    const regexTest = regex ? regex.test(value) : regexPatterns.userName.test(value);
    if (!value || value.trim() === '') {
      return {
        isValid: false,
        errorMsg: errorMsg || `${label} is empty`
      };
    } else if (regexTest === false) {
      return {
        isValid: false,
        errorMsg: errorMsg || `${label} is not valid`
      };
    } else {
      return {
        isValid: true,
        errorMsg: ''
      };
    }
  }
};

export function validate(label, value, validation) {
  return validator[validation.type](label, value, validation);
}
